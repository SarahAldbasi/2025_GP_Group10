import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hakkim/main.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';

class MqttService {
  static late MqttServerClient client;

  static Future<void> connectToMqtt() async {
    client = MqttServerClient('test.mosquitto.org', '');
    client.port = 1883;
    client.logging(on: false);
    client.keepAlivePeriod = 30;
    client.onConnected = () => print('✅ Connected to MQTT');
    client.onDisconnected = () => print('❌ Disconnected from MQTT');

    final connMessage = MqttConnectMessage()
        .withClientIdentifier(
            'flutter_client_${DateTime.now().millisecondsSinceEpoch}')
        .startClean()
        .withWillQos(MqttQos.atMostOnce);
    client.connectionMessage = connMessage;

    try {
      await client.connect();
    } catch (e) {
      print('MQTT connection failed: $e');
      client.disconnect();
      return;
    }

    if (client.connectionStatus!.state == MqttConnectionState.connected) {
      logger.f('Connected to test.mosquitto.org');
      client.subscribe(
          'uwb/+/status', MqttQos.atMostOnce); // subscribe to all tags

      client.updates!.listen((List<MqttReceivedMessage<MqttMessage?>> c) {
        final recMess = c[0].payload as MqttPublishMessage;
        final payload =
            MqttPublishPayload.bytesToStringAsString(recMess.payload.message);

        final data = json.decode(payload);

        final isActive = data['status'] == 'active';
        final docId = data['tag_id'];

        FirebaseFirestore.instance.collection('Balls').doc(docId).update({
          'isActive': isActive,
        });

        logger.d(data);

        // FirebaseFirestore.instance.collection('Balls')

        // topic example: uwb/tag_001/status
        // final topicParts = c[0].topic.split('/');
        // if (topicParts.length >= 3) {
        //   final tagId = topicParts[1]; // tag_001
        //   _setBallActive(tagId, payload);
        // }
      });
    } else {
      logger.e('Failed to connect: ${client.connectionStatus}');
    }
  }
}
