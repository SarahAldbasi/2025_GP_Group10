import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:hakkim/main.dart';
import 'local_notification_service.dart';

class FirebaseMessagingService {
  static final FirebaseMessaging _firebaseMessaging =
      FirebaseMessaging.instance;

  static Future<void> setupFirebaseMessaging() async {
    await Firebase.initializeApp();

    // Request permission
    await requestPermission();

    // Handle messages when the app is in the foreground
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      logger.i("Foreground Message: ${message.notification?.title}");
      LocalNotificationService.display(message);
    });

    // Handle messages when the app is in the background
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      logger.i("Background Message: ${message.notification?.title}");
      LocalNotificationService.display(message);
    });

    // Handle messages when the app is terminated
    RemoteMessage? initialMessage =
        await _firebaseMessaging.getInitialMessage();
    if (initialMessage != null) {
      logger.i("Terminated Message: ${initialMessage.notification?.title}");
      LocalNotificationService.display(initialMessage);
    }
  }

  static Future<void> requestPermission() async {
    await FirebaseMessaging.instance.requestPermission();
  }
}
