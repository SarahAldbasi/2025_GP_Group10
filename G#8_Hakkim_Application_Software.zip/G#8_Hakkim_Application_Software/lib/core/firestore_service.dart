import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hakkim/widgets/alert_widgets.dart';

class FirestoreService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  static Future<Map<String, dynamic>?> getRefereeData(String? userId) async {
    try {
      if (userId == null) {
        return null;
      }

      return await _firestore
          .collection('users')
          .doc(userId)
          .get()
          .then((value) {
        return value.data() as Map<String, dynamic>;
      });
    } catch (e) {
      showMessageSnackbar(e.toString());
      return null;
    }
  }
}
