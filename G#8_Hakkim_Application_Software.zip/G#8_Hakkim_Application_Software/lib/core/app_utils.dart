import 'package:flutter/material.dart';
import 'package:hakkim/screens/matches/match_filter_widget.dart';

class AppUtils {
  static Color matchColor(String status) {
    if (status == MatchStatus.pending.label) {
      return Colors.cyan;
    } else if (status == MatchStatus.notStarted.label) {
      return Colors.green;
    } else if (status == MatchStatus.upcoming.label) {
      return Colors.orange;
    } else if (status == MatchStatus.ended.label) {
      return Colors.red;
    }
    return Colors.grey;
  }
}
