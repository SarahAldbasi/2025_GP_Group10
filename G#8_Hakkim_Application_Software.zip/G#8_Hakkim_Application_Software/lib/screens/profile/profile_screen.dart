import 'dart:io';
import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/extentions.dart';
import 'package:hakkim/screens/main/splash_screen.dart';
import 'package:hakkim/widgets/alert_widgets.dart';
import 'package:hakkim/widgets/main_button_widget.dart';
import 'package:hakkim/widgets/text_field_widget.dart';
import 'package:hakkim/widgets/user_avatar_image_widget.dart';
import 'package:image_picker/image_picker.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final currentUser = FirebaseAuth.instance.currentUser;
  String? firstName;
  String? lastName;
  String? refereePin;
  String? email;

  String? avatar;

  bool isImageLoading = false;

  @override
  void initState() {
    fetchUserData();
    email = currentUser!.email!;
    avatar = currentUser!.photoURL;
    super.initState();
  }

  fetchUserData() async {
    final data = await FirebaseFirestore.instance
        .collection("users")
        .doc(currentUser!.uid)
        .get()
        .then((value) => value.data());

    setState(() {
      firstName = data!['firstName'];
      lastName = data['lastName'];
      refereePin = data['refereePin'];
    });
  }

  Future<void> pickProfileImage() async {
    try {
      setState(() {
        isImageLoading = true;
      });

      final ImagePicker picker = ImagePicker();
      XFile? imageFile = await picker.pickImage(source: ImageSource.gallery);

      if (imageFile != null) {
        avatar = await uploadProfileImage(currentUser!.uid, imageFile);
        await FirebaseFirestore.instance
            .collection("users")
            .doc(currentUser!.uid)
            .update({"photoURL": avatar});
        setState(() {
          FirebaseAuth.instance.currentUser!.updatePhotoURL(avatar);
          Get.offAll(() => SplashScreen());
        });
      }
    } catch (e) {
      showMessageSnackbar("Unable to pick an image");
    } finally {
      setState(() {
        isImageLoading = false;
      });
    }
    setState(() {});
  }

  Future<String?> uploadProfileImage(String uid, XFile imageFile) async {
    try {
      // Create a reference to the Firebase Storage location
      final Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('profile_avatars/$uid/profile_image.jpg');

      // Upload the file to Firebase Storage
      final UploadTask uploadTask =
          storageReference.putFile(File(imageFile.path));

      // Wait for the upload to complete
      final TaskSnapshot taskSnapshot = await uploadTask;

      // Get the download URL of the uploaded file
      final String downloadURL = await taskSnapshot.ref.getDownloadURL();

      // Return the download URL
      return downloadURL;
    } catch (e) {
      // Handle errors
      showMessageSnackbar('Error uploading image: $e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: ListView(
        children: [
          Container(
            width: double.infinity,
            height: size.height * 0.45,
            padding: EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(25)),
            ),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(
                  height: size.height * 0.05,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                        onPressed: () => Get.back(),
                        icon: Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 25,
                        )),
                    SizedBox(
                      width: 25,
                      height: 25,
                    )
                  ],
                ),
                Spacer(),
                Column(
                  children: [
                    Hero(
                      tag: "avatar",
                      child: GestureDetector(
                        onTap: () => pickProfileImage(),
                        child: isImageLoading
                            ? Center(
                                child: CircularProgressIndicator(),
                              )
                            : UserAvatarImageWidget(
                                imageUrl: currentUser!.photoURL.toString(),
                                radius: 55,
                              ),
                      ),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Text(
                      "${firstName ?? currentUser!.displayName!.firstName} ${lastName ?? currentUser!.displayName!.lastName}",
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      "$email",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      "#$refereePin",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
                Spacer(),
              ],
            ),
          ),
          SizedBox(
            height: 30,
          ),
          Container(
            width: double.infinity,
            // height: size.height * 0.45,
            margin: EdgeInsets.symmetric(horizontal: 15),
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.circular(25),
            ),
            child: Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                InkWell(
                  onTap: () async {
                    await Get.dialog(
                      ChangeNameWidget(
                        firstName: firstName ?? "",
                        lastName: lastName ?? "",
                      ),
                    );

                    fetchUserData();
                  },
                  child: Container(
                    height: 50,
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Icon(
                          Icons.edit,
                          color: kPrimaryColor,
                          size: 25,
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          "Change Name",
                          style: TextStyle(color: kTextColor, fontSize: 18),
                        ),
                        Spacer(),
                        Icon(
                          Icons.arrow_forward,
                          color: kGreyButtonColor,
                          size: 35,
                        ),
                      ],
                    ),
                  ),
                ),
                Divider(
                  color: kTextColor,
                  thickness: 0.25,
                  height: 25,
                ),
                InkWell(
                  onTap: () async {
                    Get.dialog(
                      ChangePasswordWidget(),
                    );
                    setState(() {});
                  },
                  child: Container(
                    height: 50,
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Icon(
                          Icons.lock,
                          color: kPrimaryColor,
                          size: 25,
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          "Change Password",
                          style: TextStyle(color: kTextColor, fontSize: 18),
                        ),
                        Spacer(),
                        Icon(
                          Icons.arrow_forward,
                          color: kGreyButtonColor,
                          size: 35,
                        ),
                      ],
                    ),
                  ),
                ),
                Divider(
                  color: kTextColor,
                  thickness: 0.25,
                  height: 25,
                ),
                InkWell(
                  onTap: () async {
                    Get.dialog(
                      ConfirmLogoutWidget(),
                    );
                    setState(() {});
                  },
                  child: Container(
                    height: 50,
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Icon(
                          Icons.logout,
                          color: Colors.red,
                          size: 25,
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          "Logout",
                          style: TextStyle(color: Colors.red, fontSize: 18),
                        ),
                        Spacer(),
                        Icon(
                          Icons.arrow_forward,
                          color: Colors.red.withValues(alpha: 0.50),
                          size: 35,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class ChangePasswordWidget extends StatefulWidget {
  const ChangePasswordWidget({
    super.key,
  });

  @override
  State<ChangePasswordWidget> createState() => _ChangePasswordWidgetState();
}

class _ChangePasswordWidgetState extends State<ChangePasswordWidget> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _currentPasswordController =
      TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool _loading = false;

  Future<void> changePassword() async {
    try {
      // Get the current user
      User? user = FirebaseAuth.instance.currentUser;

      setState(() {
        _loading = true;
      });

      if (user != null) {
        // Reauthenticate the user with their current password
        AuthCredential credential = EmailAuthProvider.credential(
          email: user.email!, // User's email
          password: _currentPasswordController.text.trim(),
        );

        await user.reauthenticateWithCredential(credential);

        // Update the password to the new password
        await user.updatePassword(_passwordController.text.trim());

        // Show success message
        Get.back();
        showMessageSnackbar('Password changed successfully!');
      } else {
        // Show error message if no user is signed in
        showMessageSnackbar('No user is currently signed in.');
      }
    } on FirebaseAuthException catch (e) {
      // Handle specific Firebase Auth errors
      String errorMessage = 'Error changing password: ${e.message}';
      if (e.code == 'wrong-password') {
        errorMessage = 'The current password is incorrect.';
      } else if (e.code == 'requires-recent-login') {
        errorMessage =
            'This operation is sensitive and requires recent authentication. Please log in again.';
      }
      showMessageSnackbar(errorMessage);
    } catch (e) {
      // Handle other errors
      showMessageSnackbar('Error changing password: $e');
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(
        sigmaX: 2.0,
        sigmaY: 2.0,
      ),
      child: Dialog(
        insetPadding: EdgeInsets.symmetric(horizontal: 15),
        child: Container(
          width: double.infinity,
          // height: size.height * 0.45,
          // height: 100,
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.circular(15),
          ),
          child: _loading
              ? SizedBox(
                  height: 200,
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              : Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "Change Password",
                        style: TextStyle(color: kTextColor, fontSize: 20),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFieldWidget(
                          controller: _currentPasswordController,
                          title: "Current Password",
                          hint: "********",
                          validator: (String? value) {
                            if (value == null || value.isEmpty) {
                              return 'Password is required';
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 20,
                      ),
                      TextFieldWidget(
                        controller: _passwordController,
                        title: "New Password",
                        hint: "********",
                        validator: (String? value) {
                          if (value == null || value.isEmpty) {
                            return 'Password is required';
                          }
                          if (value.length < 6) {
                            return 'Password must be at least 6 characters';
                          }
                          return null;
                        },
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFieldWidget(
                        controller: _confirmPasswordController,
                        title: "Confirm New Password",
                        hint: "********",
                        validator: (String? value) {
                          if (value == null || value.isEmpty) {
                            return 'Confirm Password is required';
                          }
                          if (value != _passwordController.text) {
                            return 'Passwords do not match';
                          }
                          return null;
                        },
                      ),
                      SizedBox(
                        height: 45,
                      ),
                      SizedBox(
                        height: 40,
                        child: MainButtonWidget(
                            title: "Change",
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                changePassword();
                              }
                            }),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}

class ChangeNameWidget extends StatefulWidget {
  const ChangeNameWidget(
      {super.key, required this.firstName, required this.lastName});

  final String firstName;
  final String lastName;

  @override
  State<ChangeNameWidget> createState() => _ChangeNameWidgetState();
}

class _ChangeNameWidgetState extends State<ChangeNameWidget> {
  final currentUser = FirebaseAuth.instance.currentUser;
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _secondNameController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    _firstNameController.text = widget.firstName;
    _secondNameController.text = widget.lastName;
    super.initState();
  }

  bool _loading = false;

  Future<void> updateUserName() async {
    try {
      // Get the current user
      User? user = FirebaseAuth.instance.currentUser;

      setState(() {
        _loading = true;
      });

      if (user != null) {
        // Update the display name in Firebase Auth
        await user.updateDisplayName(
            "${_firstNameController.text} ${_secondNameController.text}");

        // Update the name in Firestore under the 'users' collection
        await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .update({
          'firstName': _firstNameController.text.trim(),
          'lastName': _secondNameController.text.trim(),
        });

        // Show success message
        Get.back();
        showMessageSnackbar('User name updated successfully!');
      } else {
        // Show error message if no user is signed in
        showMessageSnackbar('No user is currently signed in.');
      }
    } catch (e) {
      // Show error message if an exception occurs
      showMessageSnackbar(
        'Error updating user name: $e',
      );
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(
        sigmaX: 2.0,
        sigmaY: 2.0,
      ),
      child: Dialog(
        insetPadding: EdgeInsets.symmetric(horizontal: 15),
        child: Container(
          width: double.infinity,
          // height: size.height * 0.45,
          // height: 100,
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.circular(15),
          ),
          child: _loading
              ? SizedBox(
                  height: 100,
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              : Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "Change Your Name",
                        style: TextStyle(color: kTextColor, fontSize: 20),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFieldWidget(
                          controller: _firstNameController,
                          title: "First Name",
                          hint: "e.g. Mohammed",
                          validator: (String? value) {
                            if (value == null || value.isEmpty) {
                              return 'First name is required';
                            } else if (!RegExp(r'^[a-zA-Z\u0600-\u06FF]+$')
                                .hasMatch(value)) {
                              return 'Only letters are allowed';
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 20,
                      ),
                      TextFieldWidget(
                          controller: _secondNameController,
                          title: "Last Name",
                          hint: "e.g. AlMohammed",
                          validator: (String? value) {
                            if (value == null || value.isEmpty) {
                              return 'Last name is required';
                            } else if (!RegExp(r'^[a-zA-Z\u0600-\u06FF]+$')
                                .hasMatch(value)) {
                              return 'Only letters are allowed';
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 45,
                      ),
                      SizedBox(
                        height: 40,
                        child: MainButtonWidget(
                            title: "Change",
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                updateUserName();
                              }
                            }),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}

class ConfirmLogoutWidget extends StatelessWidget {
  const ConfirmLogoutWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(
        sigmaX: 2.0,
        sigmaY: 2.0,
      ),
      child: Dialog(
        insetPadding: EdgeInsets.symmetric(horizontal: 15),
        child: Container(
            width: double.infinity,
            // height: size.height * 0.45,
            height: 200,
            padding: EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  "Are you sure you want to logout?",
                  style: TextStyle(color: kTextColor, fontSize: 20),
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Get.back(),
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 10),
                          height: 40.0,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15.0),
                              border:
                                  Border.all(color: Colors.red, width: 1.5)),
                          child: Center(
                            child: Text(
                              "Cancel",
                              style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          await FirebaseAuth.instance.signOut();
                          Get.offAll(() => SplashScreen());
                        },
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 10),
                          height: 40.0,
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                          child: Center(
                            child: Text(
                              "Confirm",
                              style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                )
              ],
            )),
      ),
    );
  }
}
