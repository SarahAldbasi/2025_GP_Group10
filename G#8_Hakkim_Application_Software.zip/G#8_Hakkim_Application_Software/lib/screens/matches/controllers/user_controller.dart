import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class UserController extends GetxController {
  final currentUser = FirebaseAuth.instance.currentUser;

  String get userName => currentUser?.displayName ?? 'User';
  String get userPhotoUrl => currentUser?.photoURL ?? '';
  String get userEmail => currentUser?.email ?? '';

  bool get isLoggedIn => currentUser != null;

  Future<void> signOut() async {
    await FirebaseAuth.instance.signOut();
  }
}
