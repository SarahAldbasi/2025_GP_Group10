import 'package:get/get.dart';
import 'package:hakkim/screens/main/notification_screen.dart';
import 'package:hakkim/screens/matches/all_matches_screen.dart';
import 'package:hakkim/screens/matches/match_details_screen.dart';
import 'package:hakkim/screens/matches/matches_calendar_screen.dart';
import 'package:hakkim/screens/profile/profile_screen.dart';

class NavigationController extends GetxController {
  void navigateToNotifications() {
    Get.to(
      () => NotificationScreen(),
      transition: Transition.circularReveal,
    );
  }

  void navigateToMatchesCalendar() {
    Get.to(
      () => MatchesCalendarScreen(),
      transition: Transition.circularReveal,
    );
  }

  void navigateToProfile() {
    Get.to(
      () => ProfileScreen(),
      transition: Transition.circularReveal,
    );
  }

  void navigateToAllMatches() {
    Get.to(
      () => AllMatchesScreen(),
      transition: Transition.circularReveal,
    );
  }

  void navigateToMatchDetails(Map<String, dynamic> match) {
    Get.to(
      () => MatchDetailsScreen(match: match),
      transition: Transition.circularReveal,
    );
  }
}
