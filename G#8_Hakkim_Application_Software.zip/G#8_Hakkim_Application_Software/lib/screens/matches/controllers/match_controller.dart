import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/main.dart';
import 'package:hakkim/screens/matches/match_filter_widget.dart';

class MatchController extends GetxController {
  final currentUser = FirebaseAuth.instance.currentUser;
  Timer? _countdownTimer;
  Duration _timeUntilMatch = Duration.zero;
  Map<String, dynamic>? _currentMatch;

  // Observable variables
  final Rx<Map<String, dynamic>?> nearestMatch =
      Rx<Map<String, dynamic>?>(null);
  final RxList<Map<String, dynamic>> allMatches = <Map<String, dynamic>>[].obs;
  final RxList<Map<String, dynamic>> allMatchesForScreen =
      <Map<String, dynamic>>[].obs;
  final RxBool isLoading = false.obs;
  final RxBool isLoadingAllMatches = false.obs;
  final RxString countdownText = ''.obs;

  @override
  void onInit() {
    super.onInit();
    fetchNearestMatch();
    fetchMatches();
  }

  @override
  void onClose() {
    _countdownTimer?.cancel();
    super.onClose();
  }

  Future<void> fetchNearestMatch() async {
    try {
      isLoading.value = true;

      // Get the current date or any specified date
      DateTime currentDate = DateTime.now();

      // Reference to the Firestore collection
      CollectionReference matchesCollection =
          FirebaseFirestore.instance.collection('matches');

      final mainReferee = Filter('mainReferee.id', isEqualTo: currentUser!.uid);
      final assistantReferee1 =
          Filter('assistantReferee1.id', isEqualTo: currentUser!.uid);
      final assistantReferee2 =
          Filter('assistantReferee2.id', isEqualTo: currentUser!.uid);
      final orFilter =
          Filter.or(mainReferee, assistantReferee1, assistantReferee2);

      // Query to get matches with dates greater than or equal to the current date
      QuerySnapshot upcomingMatches = await matchesCollection
          .where(orFilter)
          .where('date', isGreaterThanOrEqualTo: currentDate)
          .orderBy('date', descending: false)
          .limit(1) // Limit to 1 document (nearest match)
          .get();

      QuerySnapshot liveMatches = await matchesCollection
          .where(orFilter)
          .where('status', isEqualTo: 'started')
          .orderBy('date', descending: true)
          .limit(1) // Limit to 1 document (nearest match)
          .get();

      if (liveMatches.docs.isNotEmpty) {
        logger.i('You have a live match');
        nearestMatch.value = {
          'id': liveMatches.docs.first.id,
          ...liveMatches.docs.first.data() as Map<String, dynamic>
        };

        nearestMatch.value = {
          // "date": DateTime.now().add(3.days),
          ...nearestMatch.value!
        };
      } else if (upcomingMatches.docs.isNotEmpty) {
        nearestMatch.value = {
          'id': upcomingMatches.docs.first.id,
          ...upcomingMatches.docs.first.data() as Map<String, dynamic>
        };

        nearestMatch.value = {
          ...nearestMatch.value!,
          // "date": Timestamp.fromDate((DateTime.now().add(3.hours))),
        };
        logger.w(nearestMatch.value);
        // Start countdown for upcoming match
        _startCountdown(nearestMatch.value!);
      } else {
        nearestMatch.value = null;
      }
    } catch (e) {
      logger.e('Error fetching nearest match: $e');
      nearestMatch.value = null;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchMatches() async {
    try {
      // Reference to the Firestore collection
      CollectionReference matchesCollection =
          FirebaseFirestore.instance.collection('matches');

      final mainReferee = Filter('mainReferee.id', isEqualTo: currentUser!.uid);
      final assistantReferee1 =
          Filter('assistantReferee1.id', isEqualTo: currentUser!.uid);
      final assistantReferee2 =
          Filter('assistantReferee2.id', isEqualTo: currentUser!.uid);
      final orFilter =
          Filter.or(mainReferee, assistantReferee1, assistantReferee2);

      // Query to get matches with dates greater than or equal to the current date
      QuerySnapshot upcomingMatches = await matchesCollection
          .where(orFilter)
          .orderBy('date', descending: false)
          .limit(3) // Limit to 3 documents
          .get();

      // print(upcomingMatches.docs.length);

      // allMatches.value = upcomingMatches.docs
      //     .map((match) => match.data() as Map<String, dynamic>)
      //     .toList();

      final now = DateTime.now();

// Separate into upcoming (>= now) and past (< now)
      List<Map<String, dynamic>> upcoming = [];
      List<Map<String, dynamic>> past = [];

      for (var m in upcomingMatches.docs) {
        final date =
            (m['date'] as Timestamp).toDate(); // adjust if using string/int

        if (date.isAfter(now) || date.isAtSameMomentAs(now)) {
          upcoming.add({'id': m.id, ...m.data() as Map<String, dynamic>});
        } else {
          past.add({'id': m.id, ...m.data() as Map<String, dynamic>});
        }
      }

// Sort upcoming by nearest first (ASC)
      upcoming.sort((a, b) {
        final d1 = (a['date'] as Timestamp).toDate();
        final d2 = (b['date'] as Timestamp).toDate();
        return d1.compareTo(d2); // ASC → nearest first
      });

// Sort past by most recent first (DESC)
      past.sort((a, b) {
        final d1 = (a['date'] as Timestamp).toDate();
        final d2 = (b['date'] as Timestamp).toDate();
        return d2.compareTo(d1); // DESC → most recent past first
      });

// Combine
      allMatches.value = [...upcoming, ...past];
    } catch (e) {
      print('Error fetching matches: $e');
      allMatches.clear();
    }
  }

  Future<void> fetchAllMatchesForScreen() async {
    try {
      isLoadingAllMatches.value = true;

      // Reference to the Firestore collection
      CollectionReference matchesCollection =
          FirebaseFirestore.instance.collection('matches');

      final mainReferee = Filter('mainReferee.id', isEqualTo: currentUser!.uid);
      final assistantReferee1 =
          Filter('assistantReferee1.id', isEqualTo: currentUser!.uid);
      final assistantReferee2 =
          Filter('assistantReferee2.id', isEqualTo: currentUser!.uid);

      final Filter orFilter =
          Filter.or(mainReferee, assistantReferee1, assistantReferee2);

      var query =
          matchesCollection.where(orFilter).orderBy('date', descending: true);

      late final Filter filterFilter;

      if (filterResult != null) {
        final fromDate = (from == null)
            ? null
            : Filter('date', isGreaterThanOrEqualTo: from);

        final toDate =
            (to == null) ? null : Filter('date', isLessThanOrEqualTo: to);

        final statusFilter = (status == null)
            ? null
            : Filter('status', isEqualTo: status!.label);

        filterFilter = Filter.and(fromDate!, toDate!, statusFilter);
        query = query.where(filterFilter);
      }

      final allMatchesQuery = await query.get();

      // // Query to get all matches ordered by date descending

      // allMatchesForScreen.value = allMatchesQuery.docs
      //     .map((match) => match.data() as Map<String, dynamic>)
      //     .toList();

      final now = DateTime.now();

// Separate into upcoming (>= now) and past (< now)
      List<Map<String, dynamic>> upcoming = [];
      List<Map<String, dynamic>> past = [];

      for (var m in allMatchesQuery.docs) {
        final date =
            (m['date'] as Timestamp).toDate(); // adjust if using string/int

        if (date.isAfter(now) || date.isAtSameMomentAs(now)) {
          upcoming.add({'id': m.id, ...m.data() as Map<String, dynamic>});
        } else {
          past.add({'id': m.id, ...m.data() as Map<String, dynamic>});
        }
      }

// Sort upcoming by nearest first (ASC)
      upcoming.sort((a, b) {
        final d1 = (a['date'] as Timestamp).toDate();
        final d2 = (b['date'] as Timestamp).toDate();
        return d1.compareTo(d2); // ASC → nearest first
      });

// Sort past by most recent first (DESC)
      past.sort((a, b) {
        final d1 = (a['date'] as Timestamp).toDate();
        final d2 = (b['date'] as Timestamp).toDate();
        return d2.compareTo(d1); // DESC → most recent past first
      });

// Combine
      allMatchesForScreen.value = [...upcoming, ...past];
    } catch (e) {
      logger.e('Error fetching all matches: $e');
      allMatchesForScreen.clear();
    } finally {
      isLoadingAllMatches.value = false;
    }
  }

  void _startCountdown(Map<String, dynamic> match) {
    _currentMatch = match;
    _updateCountdown();
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      _updateCountdown();
    });
  }

  void _updateCountdown() {
    if (_currentMatch == null) return;

    final matchDate = (_currentMatch!["date"] as Timestamp).toDate();
    final now = DateTime.now();
    final difference = matchDate.difference(now);

    if (difference.isNegative) {
      // Match has already started or finished
      _timeUntilMatch = Duration.zero;
      countdownText.value = '';
      _countdownTimer?.cancel();
    } else {
      _timeUntilMatch = difference;
      countdownText.value = _formatCountdown();
    }
  }

  String _formatCountdown() {
    final days = _timeUntilMatch.inDays;
    final hours = _timeUntilMatch.inHours % 24;
    final minutes = _timeUntilMatch.inMinutes % 60;
    final seconds = _timeUntilMatch.inSeconds % 60;

    if (days > 0) {
      return '${days}d ${hours}h ${minutes}m';
    } else if (hours > 0) {
      return '${hours}h ${minutes}m ${seconds}s';
    } else if (minutes > 0) {
      return '${minutes}m ${seconds}s';
    } else {
      return '${seconds}s';
    }
  }

  String getSectionTitle() {
    if (nearestMatch.value == null) return "Upcoming Matches";

    if (nearestMatch.value!["status"] == "started") {
      return "Live Match";
    } else {
      return "Upcoming Match";
    }
  }

  bool get isLiveMatch => nearestMatch.value?["status"] == "started";
  bool get hasUpcomingMatch => nearestMatch.value != null && !isLiveMatch;

  final formKey = GlobalKey<FormState>();
  MatchStatus? status;
  DateTime? from;
  DateTime? to;
  MatchFilterResult? filterResult;

  Future<void> pickFromDate(BuildContext context) async {
    final now = DateTime.now();
    final firstDate = DateTime(now.year - 5);
    final lastDate = DateTime(now.year + 5, 12, 31);

    final picked = await showDatePicker(
      context: context,
      initialDate: from ?? to ?? now,
      firstDate: firstDate,
      lastDate: lastDate,
    );

    if (picked != null) {
      from = DateUtils.dateOnly(picked);
      // Ensure from <= to
      if (to != null && from!.isAfter(to!)) {
        to = from;
      }
      update();
    }
  }

  Future<void> pickToDate(BuildContext context) async {
    final now = DateTime.now();
    final firstDate = DateTime(now.year - 5);
    final lastDate = DateTime(now.year + 5, 12, 31);

    final picked = await showDatePicker(
      context: context,
      initialDate: to ?? from ?? now,
      firstDate: firstDate,
      lastDate: lastDate,
    );

    if (picked != null) {
      to = DateUtils.dateOnly(picked);
      // Ensure from <= to
      if (from != null && from!.isAfter(to!)) {
        from = to;
      }
      update();
    }
  }

  updateStatus(newStatus) {
    status = newStatus;
    update();
  }

  void onApply() {
    filterResult = MatchFilterResult(
      status: status,
      fromDate: from,
      toDate: to,
    );
    Get.back();
    fetchAllMatchesForScreen();
  }

  void onCearFilter() {
    filterResult = null;
    update();
    Get.back();
    fetchAllMatchesForScreen();
  }
}
