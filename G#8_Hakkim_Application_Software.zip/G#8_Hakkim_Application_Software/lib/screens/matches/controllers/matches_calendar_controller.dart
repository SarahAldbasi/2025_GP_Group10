import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/main.dart';

class MatchesCalendarController extends GetxController {
  final currentUser = FirebaseAuth.instance.currentUser;

  // UI state
  Rx<DateTime> focusedDay = DateTime.now().obs;
  Rx<DateTime> selectedDay = DateUtils.dateOnly(DateTime.now()).obs;
  final RxBool isLoading = false.obs;

  // Add a rebuild trigger to force calendar updates
  final RxInt rebuildTrigger = 0.obs;

  // Map of events grouped by day (date-only)
  final RxMap<DateTime, List<Map<String, dynamic>>> eventsByDay =
      <DateTime, List<Map<String, dynamic>>>{}.obs;

  @override
  void onInit() {
    super.onInit();
    _loadMonth(focusedDay.value);
  }

  // Normalize to date-only (no time)
  DateTime _onlyDate(DateTime dt) => DateTime(dt.year, dt.month, dt.day);

  List<Map<String, dynamic>> getEventsForDay(DateTime day) {
    final d = _onlyDate(day);
    return eventsByDay[d] ?? const <Map<String, dynamic>>[];
  }

  void onDaySelected(DateTime day, DateTime focused) {
    selectedDay.value = _onlyDate(day);
    focusedDay.value = focused;
  }

  Future<void> onPageChanged(DateTime newFocusedDay) async {
    focusedDay.value = newFocusedDay;
    selectedDay.value = _onlyDate(newFocusedDay);

    // Load events for the new month
    await _loadMonth(newFocusedDay);

    // Trigger a rebuild
    rebuildTrigger.value++;
  }

  @override
  Future<void> refresh() async {
    await _loadMonth(focusedDay.value, clearBefore: true);
    rebuildTrigger.value++;
  }

  Future<void> _loadMonth(DateTime anyDayInMonth,
      {bool clearBefore = false}) async {
    if (currentUser == null) return;

    try {
      isLoading.value = true;

      final firstDayOfMonth =
          DateTime(anyDayInMonth.year, anyDayInMonth.month, 1);
      final lastDayOfMonth = DateTime(
          anyDayInMonth.year, anyDayInMonth.month + 1, 0, 23, 59, 59, 999);

      final matchesCollection =
          FirebaseFirestore.instance.collection('matches');

      final mainReferee = Filter('mainReferee.id', isEqualTo: currentUser!.uid);
      final assistantReferee1 =
          Filter('assistantReferee1.id', isEqualTo: currentUser!.uid);
      final assistantReferee2 =
          Filter('assistantReferee2.id', isEqualTo: currentUser!.uid);
      final orFilter =
          Filter.or(mainReferee, assistantReferee1, assistantReferee2);

      final dateFrom = Filter('date', isGreaterThanOrEqualTo: firstDayOfMonth);
      final dateTo = Filter('date', isLessThanOrEqualTo: lastDayOfMonth);
      final combined = Filter.and(orFilter, dateFrom, dateTo);

      final query = await matchesCollection
          .where(combined)
          .orderBy('date', descending: false)
          .get();

      if (clearBefore) {
        eventsByDay.clear();
      } else {
        // Clear only the current month to avoid stale data
        eventsByDay.removeWhere((date, events) =>
            date.year == anyDayInMonth.year &&
            date.month == anyDayInMonth.month);
      }

      // Process the query results
      for (final doc in query.docs) {
        final data = doc.data();
        final ts = data['date'] as Timestamp?;
        if (ts == null) continue;

        final dt = ts.toDate();
        final key = _onlyDate(dt);

        // Add event to the day
        if (eventsByDay.containsKey(key)) {
          eventsByDay[key]!.add(data);
        } else {
          eventsByDay[key] = [data];
        }
      }
    } catch (e) {
      logger.e('Error loading calendar matches: $e');
    } finally {
      isLoading.value = false;
    }
  }
}
