import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/screens/matches/controllers/match_controller.dart';

/// Enum representing match status values for filtering
enum MatchStatus {
  pending('pending'),
  notStarted('not_started'),
  upcoming('upcoming'),
  ended('ended');

  final String label;

  const MatchStatus(this.label);
}

/// Result object returned from the filter dialog
class MatchFilterResult {
  final MatchStatus? status;
  final DateTime? fromDate;
  final DateTime? toDate;

  const MatchFilterResult({this.status, this.fromDate, this.toDate});
}

/// A dialog widget to filter matches by status and date range.
class MatchFilterWidget extends StatelessWidget {
  const MatchFilterWidget({
    super.key,
  });

  /// Open the filter widget as a dialog using Get.dialog.
  /// Returns a [MatchFilterResult] when Apply is pressed, or null on Cancel.
  static Future<MatchFilterResult?> show(
    BuildContext context, {
    MatchStatus? initialStatus,
    DateTime? initialFrom,
    DateTime? initialTo,
    bool barrierDismissible = true,
  }) async {
    return Get.dialog<MatchFilterResult>(
      Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        backgroundColor: kSecondaryColor,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: MatchFilterWidget(),
        ),
      ),
      barrierDismissible: barrierDismissible,
    );
  }

  String _formatDate(DateTime? date) {
    if (date == null) return '';
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<MatchController>(builder: (controller) {
      return Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: controller.formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Filter Matches',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 16),

              // Status dropdown
              DropdownButtonFormField<MatchStatus>(
                value: controller.status,
                decoration: InputDecoration(
                  labelText: 'Status',
                  labelStyle: TextStyle(color: Colors.white),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                isExpanded: true,
                dropdownColor: kSecondaryColor,
                items: [
                  const DropdownMenuItem<MatchStatus>(
                    value: null,
                    child: Text(
                      'Any',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  ...MatchStatus.values.map(
                    (e) => DropdownMenuItem<MatchStatus>(
                      value: e,
                      child: Text(
                        _statusLabel(e),
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
                onChanged: (val) => controller.updateStatus(val),
              ),
              const SizedBox(height: 24),

              // Date range
              _DateField(
                label: 'From',
                valueText: _formatDate(controller.from),
                onTap: () => controller.pickFromDate(context),
              ),
              const SizedBox(height: 24),
              _DateField(
                label: 'To',
                valueText: _formatDate(controller.to),
                onTap: () => controller.pickToDate(context),
              ),

              const SizedBox(height: 8),
              if (controller.from != null &&
                  controller.to != null &&
                  controller.from!.isAfter(controller.to!))
                const Text(
                  'From date must be before or equal to To date',
                  style: TextStyle(color: Colors.red),
                ),

              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Get.back<MatchFilterResult?>(result: null),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(
                    onPressed: () => controller.onCearFilter(),
                    child: const Text('Clear'),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () => controller.onApply(),
                    child: const Text('Apply'),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    });
  }

  static String _statusLabel(MatchStatus status) {
    switch (status) {
      case MatchStatus.pending:
        return 'Pending';
      case MatchStatus.notStarted:
        return 'Not Started';
      case MatchStatus.upcoming:
        return 'Upcoming';
      case MatchStatus.ended:
        return 'Ended';
    }
  }
}

class _DateField extends StatelessWidget {
  const _DateField({
    required this.label,
    required this.valueText,
    required this.onTap,
  });

  final String label;
  final String valueText;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          contentPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
          labelStyle: TextStyle(color: Colors.white),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          suffixIcon: const Icon(
            Icons.calendar_today,
            color: Colors.white,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14.0),
          child: Text(
            valueText.isEmpty ? 'Select date' : valueText,
            style: TextStyle(
              color: valueText.isEmpty ? Colors.white : kPrimaryColor,
              fontSize: 15,
            ),
          ),
        ),
      ),
    );
  }
}
