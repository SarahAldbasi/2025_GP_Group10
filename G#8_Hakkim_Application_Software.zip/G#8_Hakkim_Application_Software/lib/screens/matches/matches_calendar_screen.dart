import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/core/app_utils.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:jiffy/jiffy.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/extentions.dart';
import 'controllers/matches_calendar_controller.dart';
import 'controllers/navigation_controller.dart';

class MatchesCalendarScreen extends StatefulWidget {
  const MatchesCalendarScreen({super.key});

  @override
  State<MatchesCalendarScreen> createState() => _MatchesCalendarScreenState();
}

class _MatchesCalendarScreenState extends State<MatchesCalendarScreen> {
  late final MatchesCalendarController controller;

  @override
  void initState() {
    controller = Get.put(MatchesCalendarController());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSecondaryColor,
      appBar: AppBar(
        backgroundColor: kSecondaryColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: Get.back,
        ),
        title: const Text(
          'Matches Calendar',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        // actions: [
        //   IconButton(
        //     onPressed: controller.refresh,
        //     icon: const Icon(Icons.refresh, color: Colors.white),
        //   )
        // ],
      ),
      body: Column(
        children: [
          CalendarWidget(controller: controller),
          const SizedBox(height: 10),
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: kBackgroundColor,
                borderRadius: BorderRadius.circular(20),
              ),
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Obx(
                () => EventListWidget(
                  events:
                      controller.getEventsForDay(controller.selectedDay.value),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CalendarWidget extends StatelessWidget {
  const CalendarWidget({
    super.key,
    required this.controller,
  });

  final MatchesCalendarController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: kBackgroundColor,
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Obx(() {
        // Create a unique key that forces rebuild when events change
        final focusedDay = controller.focusedDay.value;
        final eventsCount = controller.eventsByDay.values
            .fold<int>(0, (sum, events) => sum + events.length);
        final calendarKey =
            'calendar_${focusedDay.year}_${focusedDay.month}_${eventsCount}_${controller.rebuildTrigger.value}';

        return TableCalendar<Map<String, dynamic>>(
          key: ValueKey(calendarKey),
          firstDay: DateTime.now().subtract(const Duration(days: 90)),
          lastDay: DateTime.now().add(const Duration(days: 180)),
          focusedDay: focusedDay,
          selectedDayPredicate: (day) =>
              isSameDay(day, controller.selectedDay.value),
          eventLoader: (day) => controller.getEventsForDay(day),
          startingDayOfWeek: StartingDayOfWeek.monday,
          calendarFormat: CalendarFormat.month,
          headerStyle: const HeaderStyle(
            titleCentered: true,
            formatButtonVisible: false,
            titleTextStyle: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 16,
            ),
            leftChevronIcon: Icon(Icons.chevron_left, color: Colors.white),
            rightChevronIcon: Icon(Icons.chevron_right, color: Colors.white),
          ),
          daysOfWeekStyle: const DaysOfWeekStyle(
            weekdayStyle: TextStyle(color: Colors.white70),
            weekendStyle: TextStyle(color: Colors.white70),
          ),
          calendarStyle: CalendarStyle(
            defaultTextStyle: const TextStyle(color: Colors.white),
            weekendTextStyle: const TextStyle(color: Colors.white),
            outsideDaysVisible: false,
            selectedDecoration: const BoxDecoration(
              color: kPrimaryColor,
              shape: BoxShape.circle,
            ),
            todayDecoration: BoxDecoration(
              border: Border.all(color: kPrimaryColor, width: 1.5),
              shape: BoxShape.circle,
            ),
            markerDecoration: const BoxDecoration(
              color: kPrimaryColor,
              shape: BoxShape.circle,
            ),
            markersMaxCount: 3,
          ),
          onDaySelected: (selectedDay, focusedDay) {
            controller.onDaySelected(selectedDay, focusedDay);
          },
          onPageChanged: (focusedDay) {
            controller.onPageChanged(focusedDay);
          },
        );
      }),
    );
  }
}

class EventListWidget extends StatelessWidget {
  const EventListWidget({super.key, required this.events});

  final List<Map<String, dynamic>> events;

  @override
  Widget build(BuildContext context) {
    if (events.isEmpty) {
      return const Center(
        child: Text(
          'No match for this day',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      itemCount: events.length,
      separatorBuilder: (_, __) => const Divider(
        color: kTextColor,
        height: 24,
        thickness: 0.25,
      ),
      itemBuilder: (context, index) {
        final match = events[index];
        final homeName = match.getNested('homeTeam.name').toString();
        final awayName = match.getNested('awayTeam.name').toString();
        final date = (match['date'] as Timestamp).toDate();
        final timeStr =
            Jiffy.parse(date.toIso8601String()).format(pattern: 'hh:mm a');
        final league = match.getNested('league')?.toString() ?? '';

        return InkWell(
          onTap: () =>
              Get.find<NavigationController>().navigateToMatchDetails(match),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: kGreyButtonColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      timeStr,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '$homeName  vs  $awayName',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.circle,
                              size: 12,
                              color: AppUtils.matchColor(
                                  match.getNested('status')),
                            ),
                            const SizedBox(width: 5),
                            Text(
                              match.getNested('status').toString(),
                              style: const TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                        if (league.isNotEmpty)
                          Text(
                            league,
                            style: const TextStyle(
                              color: kTextColor,
                              fontSize: 12,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
              const Divider(color: Colors.white12),
            ],
          ),
        );
      },
    );
  }
}
