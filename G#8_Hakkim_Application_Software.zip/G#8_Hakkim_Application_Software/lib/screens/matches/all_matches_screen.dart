import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/extentions.dart';
import 'package:hakkim/screens/matches/controllers/match_controller.dart';
import 'package:hakkim/screens/matches/match_details_screen.dart';
import 'package:hakkim/screens/matches/match_filter_widget.dart';
import 'package:hakkim/widgets/grey_button_widget.dart';
import 'package:hakkim/widgets/team_logo_image_widget.dart';
import 'package:jiffy/jiffy.dart';

class AllMatchesScreen extends StatelessWidget {
  const AllMatchesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final matchController = Get.find<MatchController>();

    // Fetch all matches when screen loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      matchController.fetchAllMatchesForScreen();
    });

    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: RefreshIndicator(
        onRefresh: () async {
          matchController.fetchAllMatchesForScreen();
        },
        child: ListView(
          children: [
            SizedBox(
              height: size.height * 0.075,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                    onPressed: () => Get.back(),
                    icon: Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                      size: 25,
                    )),
                Text(
                  "All Matches",
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                GetBuilder<MatchController>(builder: (controller) {
                  return Stack(
                    children: [
                      IconButton(
                        onPressed: () => MatchFilterWidget.show(context),
                        icon: Icon(
                          FontAwesomeIcons.filter,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      if (controller.filterResult != null)
                        Positioned(
                          top: 10,
                          right: 12,
                          child: Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: kPrimaryColor,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                    ],
                  );
                })
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Obx(() {
              if (matchController.isLoadingAllMatches.value) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }

              if (matchController.allMatchesForScreen.isEmpty) {
                return Center(child: _buildNoMatchesWidget());
              }

              return ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                shrinkWrap: true,
                primary: false,
                children: matchController.allMatchesForScreen
                    .map((match) => _buildMatchCardWidget(match))
                    .toList(),
              );
            })
          ],
        ),
      ),
    );
  }

  Widget _buildMatchCardWidget(Map<String, dynamic> match) {
    final DateTime? createdAt =
        (match.getNested('createdAt') as Timestamp?)?.toDate();
    return Stack(
      children: [
        Container(
          width: double.infinity,
          margin: EdgeInsets.only(bottom: 20),
          padding: EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.circular(25),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                height: 85,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Flexible(
                      flex: 2,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TeamLogoImageWidget(
                            imageUrl:
                                match.getNested("homeTeam.logo").toString(),
                            width: 40,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: Text(
                              match.getNested("homeTeam.name").toString(),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Flexible(
                      flex: 1,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (createdAt != null &&
                              createdAt.isAfter(
                                DateTime.now().subtract(Duration(days: 3)),
                              )) ...[
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 5, vertical: 2.5),
                              decoration: BoxDecoration(
                                color: kPrimaryColor,
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Text(
                                'New',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                          GreyButtonWidget(
                              title: "VS",
                              width: 50,
                              height: 30,
                              fontSize: 15,
                              isBold: true,
                              onPress: () {}),
                        ],
                      ),
                    ),
                    Flexible(
                      flex: 2,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Text(
                              match.getNested("awayTeam.name").toString(),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          TeamLogoImageWidget(
                            imageUrl:
                                match.getNested("awayTeam.logo").toString(),
                            width: 40,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                          color: kBackgroundColor2,
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(25))),
                      alignment: Alignment.center,
                      child: Text(
                        Jiffy.parse((match["date"] as Timestamp)
                                .toDate()
                                .toIso8601String())
                            .format(pattern: "dd MMM yyyy hh:mm a"),
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: kTextColor,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () => Get.to(
                        () => MatchDetailsScreen(
                          match: match,
                        ),
                        transition: Transition.circularReveal,
                      ),
                      child: Container(
                        height: 50,
                        decoration: BoxDecoration(
                            color: kPrimaryColor,
                            borderRadius: BorderRadius.only(
                                bottomRight: Radius.circular(25))),
                        alignment: Alignment.center,
                        child: Text(
                          "View details",
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: kGreyButtonColor,
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildNoMatchesWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.sports_basketball_sharp,
            color: kPrimaryColor,
            size: 100,
          ),
          SizedBox(height: 20),
          Text(
            "   No matches found",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
