import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/extentions.dart';
import 'package:hakkim/screens/matches/controllers/match_controller.dart';
import 'package:hakkim/screens/matches/controllers/navigation_controller.dart';
import 'package:hakkim/screens/matches/controllers/user_controller.dart';
import 'package:hakkim/widgets/grey_button_widget.dart';
import 'package:hakkim/widgets/team_logo_image_widget.dart';
import 'package:hakkim/widgets/user_avatar_image_widget.dart';
import 'package:jiffy/jiffy.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Initialize controllers
    final matchController = Get.put(MatchController());
    final userController = Get.put(UserController());
    final navigationController = Get.put(NavigationController());

    Size size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: kSecondaryColor,
        body: RefreshIndicator(
          onRefresh: () async {
            matchController.fetchNearestMatch();
            matchController.fetchMatches();
          },
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            children: [
              SizedBox(
                height: size.height * 0.1,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildAvatarWidget(userController, navigationController),
                  Row(
                    children: [
                      IconButton(
                        onPressed:
                            navigationController.navigateToMatchesCalendar,
                        icon: Icon(
                          Icons.calendar_today,
                          color: Colors.white,
                          size: 25,
                        ),
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      IconButton(
                        onPressed: navigationController.navigateToNotifications,
                        icon: Icon(
                          Icons.notifications,
                          color: Colors.white,
                          size: 25,
                        ),
                      ),
                    ],
                  )
                ],
              ),
              SizedBox(
                height: 50,
              ),
              _buildUpcomingMatchWidget(
                  size, matchController, navigationController),
              SizedBox(
                height: 30,
              ),
              _buildAllMatchesWidget(
                  size, matchController, navigationController),
              SizedBox(
                height: size.height * 0.05,
              ),
            ],
          ),
        ));
  }

  Widget _buildAvatarWidget(UserController userController,
      NavigationController navigationController) {
    return Row(
      children: [
        Hero(
          tag: "avatar",
          child: GestureDetector(
            onTap: navigationController.navigateToProfile,
            child: UserAvatarImageWidget(
              imageUrl: userController.userPhotoUrl,
            ),
          ),
        ),
        SizedBox(
          width: 15,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Hello!",
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            Text(
              userController.userName,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                color: kTextColor,
              ),
            ),
          ],
        )
      ],
    );
  }

  Widget _buildUpcomingMatchWidget(Size size, MatchController matchController,
      NavigationController navigationController) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: kBackgroundColor2,
        borderRadius: BorderRadius.circular(25),
      ),
      child: Obx(() {
        if (matchController.isLoading.value) {
          return SizedBox(
            height: 300,
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        final lastMatch = matchController.nearestMatch.value;
        final sectionTitle = matchController.getSectionTitle();

        return Column(
          children: [
            Container(
              width: size.width * 0.5,
              height: 40,
              decoration: BoxDecoration(
                  color: kPrimaryColor,
                  borderRadius:
                      BorderRadius.vertical(bottom: Radius.circular(25))),
              child: Center(
                child: Text(
                  sectionTitle,
                  style: TextStyle(
                      fontSize: 17,
                      color: kSecondaryColor,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: lastMatch == null
                  ? _buildNoMatchesWidget()
                  : _buildMatchDetailsWidget(
                      lastMatch, matchController, navigationController),
            ),
            if (lastMatch != null)
              Column(
                children: [
                  SizedBox(
                    height: 25,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: GreyButtonWidget(
                      title: "Match Details",
                      onPress: () => navigationController
                          .navigateToMatchDetails(lastMatch),
                    ),
                  ),
                ],
              ),
            SizedBox(
              height: 25,
            ),
          ],
        );
      }),
    );
  }

  Widget _buildNoMatchesWidget() {
    return Center(
      child: Column(
        children: [
          Icon(
            Icons.sports_basketball_sharp,
            color: kPrimaryColor,
            size: 100,
          ),
          SizedBox(
            height: 25,
          ),
          Text(
            "NO UPCOMING MATCHES",
            style: TextStyle(
                fontSize: 15, color: kTextColor, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildMatchDetailsWidget(
      Map<String, dynamic> lastMatch,
      MatchController matchController,
      NavigationController navigationController) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              flex: 1,
              child: Column(
                children: [
                  TeamLogoImageWidget(
                    imageUrl: "${lastMatch.getNested("homeTeam.logo")}",
                    width: 65,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  LayoutBuilder(builder: (context, constraints) {
                    return SizedBox(
                      width: constraints.maxWidth,
                      child: Text(
                        "${lastMatch.getNested("homeTeam.name".toString())} ",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
            Flexible(
              flex: 1,
              child: Column(
                children: [
                  SizedBox(
                    height: 25,
                  ),
                  GreyButtonWidget(
                      title: "VS", width: 60, isBold: true, onPress: () {}),
                  SizedBox(
                    height: 25,
                  ),
                  Text(
                    Jiffy.parse((lastMatch["date"] as Timestamp)
                            .toDate()
                            .toIso8601String())
                        .format(pattern: "dd MMM yyyy"),
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    Jiffy.parse((lastMatch["date"] as Timestamp)
                            .toDate()
                            .toIso8601String())
                        .format(pattern: "hh:mm a"),
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                  ),
                  if (lastMatch["status"] != "started" &&
                      matchController.countdownText.value.isNotEmpty)
                    Obx(() => Container(
                          margin: EdgeInsets.only(top: 8),
                          padding:
                              EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: kPrimaryColor,
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Text(
                            matchController.countdownText.value,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        )),
                ],
              ),
            ),
            Flexible(
              flex: 1,
              child: Column(
                children: [
                  TeamLogoImageWidget(
                    imageUrl: lastMatch.getNested("awayTeam.logo").toString(),
                    width: 65,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  LayoutBuilder(builder: (context, constraints) {
                    return SizedBox(
                      width: constraints.maxWidth,
                      child: Text(
                        lastMatch.getNested("awayTeam.name").toString(),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        )
      ],
    );
  }

  Widget _buildAllMatchesWidget(Size size, MatchController matchController,
      NavigationController navigationController) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "All Matches",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w500,
            color: Colors.white,
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.circular(25),
          ),
          child: Obx(() {
            final matches = matchController.allMatches;

            if (matches.isEmpty) {
              return Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.sports_basketball_sharp,
                      color: kPrimaryColor,
                      size: 100,
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Text(
                      "NO MATCHES",
                      style: TextStyle(
                          fontSize: 15,
                          color: kTextColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              );
            }

            return Column(children: [
              SizedBox(
                height: 20,
              ),
              ...matches.map((match) =>
                  _buildMatchCardWidget(match, navigationController)),
              SizedBox(
                height: 10,
              ),
              GreyButtonWidget(
                title: "See All",
                onPress: navigationController.navigateToAllMatches,
                width: size.width * 0.4,
              ),
              SizedBox(
                height: 20,
              ),
            ]);
          }),
        ),
      ],
    );
  }

  Widget _buildMatchCardWidget(
      Map<String, dynamic> match, NavigationController navigationController) {
    final DateTime? createdAt =
        (match.getNested('createdAt') as Timestamp?)?.toDate();
    return InkWell(
      onTap: () => navigationController.navigateToMatchDetails(match),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  flex: 2,
                  child: Row(
                    children: [
                      TeamLogoImageWidget(
                        imageUrl: match.getNested("homeTeam.logo").toString(),
                        width: 40,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Text(
                          match.getNested("homeTeam.name").toString(),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Flexible(
                  flex: 1,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (createdAt != null &&
                          createdAt.isAfter(
                            DateTime.now().subtract(Duration(days: 3)),
                          )) ...[
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 5, vertical: 2.5),
                          decoration: BoxDecoration(
                            color: kPrimaryColor,
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Text(
                            'New',
                            style: TextStyle(
                              fontSize: 8,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                      GreyButtonWidget(
                          title: "VS",
                          width: 50,
                          height: 30,
                          fontSize: 15,
                          isBold: true,
                          onPress: () {}),
                    ],
                  ),
                ),
                Flexible(
                  flex: 2,
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          ("${match.getNested("awayTeam.name")} "),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      TeamLogoImageWidget(
                        imageUrl: match.getNested("awayTeam.logo").toString(),
                        width: 40,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: kTextColor,
            thickness: 0.25,
            height: 25,
          ),
        ],
      ),
    );
  }
}
