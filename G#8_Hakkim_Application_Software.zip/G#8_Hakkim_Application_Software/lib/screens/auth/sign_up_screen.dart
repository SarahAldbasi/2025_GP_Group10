import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pw_validator/flutter_pw_validator.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/main.dart';
import 'package:hakkim/screens/auth/log_in_screen.dart';
import 'package:hakkim/screens/main/splash_screen.dart';
import 'package:hakkim/widgets/alert_widgets.dart';
import 'package:hakkim/widgets/main_button_widget.dart';
import 'package:hakkim/widgets/text_field_widget.dart';
import 'package:image_picker/image_picker.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _secondNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final FocusNode _passwordFocusNode = FocusNode();
  final FocusNode _confirmPasswordFocusNode = FocusNode();
  bool _isPasswordFieldFocused = false;

  XFile? imageFile;
  File? documentFile;

  bool _loading = false;

  Future<void> pickDocumentFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'txt'],
      );

      if (result != null) {
        documentFile = File(result.files.single.path!);
      }
    } catch (e) {
      showMessageSnackbar("Unable to pick a file");
    }
    setState(() {});
  }

  Future<String?> uploadDocumentFile(String uid) async {
    try {
      // Create a reference to Firebase Storage location
      final Reference storageReference = FirebaseStorage.instance.ref().child(
          'documents/$uid/document.${documentFile!.path.split('.').last}');

      // Upload the file
      final UploadTask uploadTask = storageReference.putFile(documentFile!);

      // Wait for upload completion
      final TaskSnapshot taskSnapshot = await uploadTask;

      // Get the download URL
      final String downloadURL = await taskSnapshot.ref.getDownloadURL();

      // Return the download URL
      return downloadURL;
    } catch (e) {
      print('Error uploading document: $e');
      logger.e(e);
      return null;
    }
  }

  Future<void> pickProfileImage() async {
    try {
      final ImagePicker picker = ImagePicker();
      imageFile =
          await picker.pickImage(source: ImageSource.gallery) ?? imageFile;
    } catch (e) {
      showMessageSnackbar("Unable to pick an image");
    }
    setState(() {});
  }

  Future<String?> uploadProfileImage(String uid) async {
    try {
      // Create a reference to the Firebase Storage location
      final Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('profile_avatars/$uid/profile_image.jpg');

      // Upload the file to Firebase Storage
      final UploadTask uploadTask =
          storageReference.putFile(File(imageFile!.path));

      // Wait for the upload to complete
      final TaskSnapshot taskSnapshot = await uploadTask;

      // Get the download URL of the uploaded file
      final String downloadURL = await taskSnapshot.ref.getDownloadURL();

      // Return the download URL
      return downloadURL;
    } catch (e) {
      // Handle errors
      print('Error uploading image: $e');
      logger.e(e);
      return null;
    }
  }

  Future<void> createUserWithEmailAndPassword() async {
    try {
      setState(() {
        _loading = true;
      });

      // Create user with Firebase Auth
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      final String? avatarPhotoUrl =
          await uploadProfileImage(userCredential.user!.uid);

      final String? documentUrl =
          await uploadDocumentFile(userCredential.user!.uid);

      // Save user data in Firestore
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user!.uid)
          .set({
        'firstName': _firstNameController.text.trim(),
        'lastName': _secondNameController.text.trim(),
        'email': _emailController.text.trim(),
        "photoURL": avatarPhotoUrl,
        "phoneNumber": _phoneController.text.trim(),
        "isAvailable": true,
        "role": "referee",
        "verificationStatus": "pending",
        "document": documentUrl,
        "uid": userCredential.user!.uid,
        "fcm_token": await FirebaseMessaging.instance.getToken(),
        'createdAt': Timestamp.now(),
      });

      await FirebaseAuth.instance.currentUser!.updateDisplayName(
          '${_firstNameController.text} ${_secondNameController.text}');
      await FirebaseAuth.instance.currentUser!.updatePhotoURL(avatarPhotoUrl);

      // Show success message
      showMessageSnackbar('User created successfully!');

      // Navigate to HomeScreen with circle reveal transition
      Get.offAll(() => SplashScreen(), transition: Transition.circularReveal);
    } on FirebaseAuthException catch (e) {
      // Handle Firebase Auth errors
      showMessageSnackbar('Error: ${e.message}');
    } catch (e) {
      // Handle other errors
      showMessageSnackbar('Error: $e');
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  void initState() {
    _passwordFocusNode.addListener(() {
      setState(() {
        _isPasswordFieldFocused = _passwordFocusNode.hasFocus;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(children: [
                      SizedBox(
                        height: size.height * 0.125,
                      ),
                      Image(
                        image: AssetImage("assets/images/app_logo.png"),
                        width: size.width * 0.6,
                      ),
                      SizedBox(
                        height: 50,
                      ),
                    ]),
                  ),
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: kBackgroundColor,
                        borderRadius: BorderRadius.vertical(
                          top: Radius.circular(30),
                        ),
                      ),
                      child: ListView(
                        // crossAxisAlignment: CrossAxisAlignment.start,
                        padding: const EdgeInsets.symmetric(horizontal: 30),
                        children: [
                          SizedBox(
                            height: 30,
                          ),
                          Text(
                            "Let’s get started!",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              color: kTextColor,
                            ),
                          ),
                          SizedBox(
                            height: 25,
                          ),
                          if (imageFile == null)
                            InkWell(
                              onTap: () => pickProfileImage(),
                              child: CircleAvatar(
                                radius: 50,
                                backgroundColor: kBackgroundColor2,
                                child: Icon(
                                  Icons.image,
                                  color: kPrimaryColor,
                                  size: 35,
                                ),
                              ),
                            )
                          else
                            InkWell(
                              onTap: () => pickProfileImage(),
                              child: CircleAvatar(
                                radius: 50,
                                backgroundColor: kBackgroundColor2,
                                backgroundImage:
                                    FileImage(File(imageFile!.path)),
                              ),
                            ),
                          SizedBox(
                            height: 20,
                          ),
                          TextFieldWidget(
                              controller: _firstNameController,
                              title: "First Name",
                              hint: "e.g Mohammed",
                              validator: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'First name is required';
                                } else if (!RegExp(r'^[a-zA-Z\u0600-\u06FF]+$')
                                    .hasMatch(value)) {
                                  return 'Only letters are allowed';
                                }
                                return null;
                              }),
                          SizedBox(
                            height: 20,
                          ),
                          TextFieldWidget(
                              controller: _secondNameController,
                              title: "Last Name",
                              hint: "e.g AlMohammed",
                              validator: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Last name is required';
                                } else if (!RegExp(r'^[a-zA-Z\u0600-\u06FF]+$')
                                    .hasMatch(value)) {
                                  return 'Only letters are allowed';
                                }
                                return null;
                              }),
                          SizedBox(
                            height: 20,
                          ),
                          TextFieldWidget(
                            controller: _emailController,
                            title: "Email",
                            hint: "example@example.com",
                            validator: (String? value) {
                              if (value == null || value.isEmpty) {
                                return 'Email is required';
                              }
                              if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                                  .hasMatch(value)) {
                                return 'Enter a valid email address';
                              }
                              return null;
                            },
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          TextFieldWidget(
                              controller: _phoneController,
                              title: "Phone Number",
                              hint: "05xxxxxxxx",
                              validator: (String? phoneNumber) {
                                final regex = RegExp(
                                    r'^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$');
                                if (phoneNumber == null ||
                                    phoneNumber.isEmpty) {
                                  return 'Phone number is required';
                                } else if (!regex.hasMatch(phoneNumber)) {
                                  return 'Invalid phone number';
                                }
                                return null;
                              }),
                          SizedBox(
                            height: 20,
                          ),
                          TextFieldWidget(
                            controller: _passwordController,
                            focusNode: _passwordFocusNode,
                            title: "Password",
                            hint: "********",
                            isPassword: true,
                            validator: (String? value) {
                              if (value == null || value.isEmpty) {
                                return 'Password is required';
                              }
                              if (value.length < 8) {
                                return 'Password must be at least 8 characters';
                              }
                              if (!RegExp(r'[A-Z]').hasMatch(value)) {
                                return 'Must include an uppercase letter';
                              }
                              if (!RegExp(r'[a-z]').hasMatch(value)) {
                                return 'Must include a lowercase letter';
                              }
                              if (!RegExp(r'\d').hasMatch(value)) {
                                return 'Must include a digit';
                              }
                              if (!RegExp(r'[@$!%*?&#]').hasMatch(value)) {
                                return 'Must include a special character';
                              }
                              return null;
                            },
                          ),
                          if (_isPasswordFieldFocused) ...[
                            SizedBox(
                              height: 20,
                            ),
                            FlutterPwValidator(
                                controller: _passwordController,
                                minLength: 8,
                                uppercaseCharCount: 1,
                                specialCharCount: 1,
                                lowercaseCharCount: 1,
                                numericCharCount: 1,
                                width: 400,
                                height: 175,
                                onSuccess: () {},
                                onFail: () {}),
                          ],
                          SizedBox(
                            height: 20,
                          ),
                          TextFieldWidget(
                            controller: _confirmPasswordController,
                            focusNode: _confirmPasswordFocusNode,
                            title: "Confirm Password",
                            hint: "********",
                            isPassword: true,
                            validator: (String? value) {
                              if (value == null || value.isEmpty) {
                                return 'Confirm Password is required';
                              }
                              if (value != _passwordController.text) {
                                return 'Passwords do not match';
                              }
                              return null;
                            },
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          // Text(
                          //   "Upload identification",
                          //   style: TextStyle(
                          //     fontSize: 15,
                          //     color: kTextColor,
                          //   ),
                          // ),
                          // SizedBox(
                          //   height: 5,
                          // ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              InkWell(
                                onTap: () => pickDocumentFile(),
                                child: Container(
                                  width: double.infinity,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    color: kBackgroundColor2,
                                    borderRadius: BorderRadius.circular(25),
                                  ),
                                  child: Center(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.file_copy,
                                          color: kTextColor,
                                          size: 25,
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        if (documentFile == null)
                                          Text(
                                            "Identification Document",
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: kTextColor,
                                            ),
                                          )
                                        else
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 15),
                                            child: Text(
                                              documentFile!.path
                                                  .split('/')
                                                  .last,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                              style: TextStyle(
                                                fontSize: 14,
                                                color: kTextColor,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              if (documentFile == null) ...[
                                SizedBox(
                                  height: 3,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 30),
                                  child: Text(
                                    "document is required",
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                        fontSize: 12, color: Colors.red),
                                  ),
                                ),
                              ]
                            ],
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          MainButtonWidget(
                              title: "SIGN UP",
                              onPressed: () {
                                if (_formKey.currentState!.validate() &&
                                    documentFile != null) {
                                  createUserWithEmailAndPassword();
                                }
                              }),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Already have an account?",
                                style:
                                    TextStyle(fontSize: 15, color: kTextColor),
                              ),
                              TextButton(
                                onPressed: () => Get.offAll(() => LogInScreen(),
                                    transition: Transition.leftToRight),
                                child: Text(
                                  " Log in",
                                  style: TextStyle(
                                      fontSize: 15, color: kPrimaryColor),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
    );
  }
}
