import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/screens/auth/sign_up_screen.dart';
import 'package:hakkim/screens/main/splash_screen.dart';
import 'package:hakkim/screens/matches/home_screen.dart';
import 'package:hakkim/widgets/alert_widgets.dart';
import 'package:hakkim/widgets/main_button_widget.dart';
import 'package:hakkim/widgets/text_field_widget.dart';

class LogInScreen extends StatefulWidget {
  const LogInScreen({super.key});

  @override
  State<LogInScreen> createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _loading = false;

  Future<void> loginUserWithEmailAndPassword() async {
    try {
      setState(() {
        _loading = true;
      });

      // Sign in with Firebase Auth

      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      await FirebaseFirestore.instance
          .collection("users")
          .doc(userCredential.user!.uid)
          .update({"fcm_token": await FirebaseMessaging.instance.getToken()});

      // Show success message
      showMessageSnackbar('Login successful!');

      // Navigate to HomeScreen with circular reveal transition
      Get.offAll(() => SplashScreen(), transition: Transition.circularReveal);
    } on FirebaseAuthException catch (e) {
      // Handle Firebase Auth errors
      if (e.code == 'user-not-found') {
        showMessageSnackbar('Error: No user found with this email.');
      } else if (e.code == 'wrong-password') {
        showMessageSnackbar('Error: Incorrect password.');
      } else {
        showMessageSnackbar('Error: ${e.message}');
      }
    } catch (e) {
      // Handle other errors
      showMessageSnackbar('Error: $e');
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  Future<void> resetPassword() async {
    if (_emailController.text.isEmpty) {
      showMessageSnackbar("Please enter your email");
      return;
    }

    try {
      await FirebaseAuth.instance
          .sendPasswordResetEmail(email: _emailController.text.trim());
      showMessageSnackbar("Password reset email sent! Check your inbox.");
    } catch (e) {
      showMessageSnackbar("Error Sending Verification Email");
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(children: [
                      SizedBox(
                        height: size.height * 0.125,
                      ),
                      Image(
                        image: AssetImage("assets/images/app_logo.png"),
                        width: size.width * 0.6,
                      ),
                      SizedBox(
                        height: 100,
                      ),
                    ]),
                  ),
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: kBackgroundColor,
                        borderRadius: BorderRadius.vertical(
                          top: Radius.circular(30),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 30),
                        child: ListView(
                          // crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 30,
                            ),
                            Text(
                              "Welcome Back!",
                              style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                                color: kTextColor,
                              ),
                            ),
                            SizedBox(
                              height: 60,
                            ),
                            TextFieldWidget(
                              controller: _emailController,
                              title: "Email",
                              hint: "example@example.com",
                              validator: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Email is required';
                                }

                                return null;
                              },
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            TextFieldWidget(
                              controller: _passwordController,
                              title: "Password",
                              hint: "********",
                              isPassword: true,
                              validator: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Password is required';
                                }

                                return null;
                              },
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: TextButton(
                                onPressed: () => resetPassword(),
                                child: Text(
                                  "Forget password?",
                                  style: TextStyle(
                                      fontSize: 15, color: kTextColor),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 50,
                            ),
                            MainButtonWidget(
                                title: "LOG IN",
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {
                                    loginUserWithEmailAndPassword();
                                  }
                                }),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "Don’t have an account?",
                                  style: TextStyle(
                                      fontSize: 15, color: kTextColor),
                                ),
                                TextButton(
                                  onPressed: () => Get.offAll(
                                      () => SignUpScreen(),
                                      transition: Transition.rightToLeft),
                                  child: Text(
                                    "Sign up",
                                    style: TextStyle(
                                        fontSize: 15, color: kPrimaryColor),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
    );
  }
}

class ResetPasswordWidget extends StatefulWidget {
  const ResetPasswordWidget({
    super.key,
  });

  @override
  State<ResetPasswordWidget> createState() => _ChangePasswordWidgetState();
}

class _ChangePasswordWidgetState extends State<ResetPasswordWidget> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _currentPasswordController =
      TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool _loading = false;

  Future<void> changePassword() async {
    try {
      // Get the current user
      User? user = FirebaseAuth.instance.currentUser;

      setState(() {
        _loading = true;
      });

      if (user != null) {
        // Reauthenticate the user with their current password
        AuthCredential credential = EmailAuthProvider.credential(
          email: user.email!, // User's email
          password: _currentPasswordController.text.trim(),
        );

        await user.reauthenticateWithCredential(credential);

        // Update the password to the new password
        await user.updatePassword(_passwordController.text.trim());

        // Show success message
        Get.back();
        showMessageSnackbar('Password changed successfully!');
      } else {
        // Show error message if no user is signed in
        showMessageSnackbar('No user is currently signed in.');
      }
    } on FirebaseAuthException catch (e) {
      // Handle specific Firebase Auth errors
      String errorMessage = 'Error changing password: ${e.message}';
      if (e.code == 'wrong-password') {
        errorMessage = 'The current password is incorrect.';
      } else if (e.code == 'requires-recent-login') {
        errorMessage =
            'This operation is sensitive and requires recent authentication. Please log in again.';
      }
      showMessageSnackbar(errorMessage);
    } catch (e) {
      // Handle other errors
      showMessageSnackbar('Error changing password: $e');
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(
        sigmaX: 2.0,
        sigmaY: 2.0,
      ),
      child: Dialog(
        insetPadding: EdgeInsets.symmetric(horizontal: 15),
        child: Container(
          width: double.infinity,
          // height: size.height * 0.45,
          // height: 100,
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.circular(15),
          ),
          child: _loading
              ? SizedBox(
                  height: 200,
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              : Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "Change Password",
                        style: TextStyle(color: kTextColor, fontSize: 20),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFieldWidget(
                        controller: _currentPasswordController,
                        title: "Current Password",
                        hint: "*******",
                        validator: (String? value) {
                          if (value == null || value.isEmpty) {
                            return 'Current password is required';
                          }
                          return null;
                        },
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFieldWidget(
                        controller: _passwordController,
                        title: "New Password",
                        hint: "*******",
                        validator: (String? value) {
                          if (value == null || value.isEmpty) {
                            return 'Password is required';
                          }
                          if (value.length < 6) {
                            return 'Password must be at least 6 characters';
                          }
                          return null;
                        },
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFieldWidget(
                        controller: _confirmPasswordController,
                        title: "Confirm New Password",
                        hint: "********",
                        validator: (String? value) {
                          if (value == null || value.isEmpty) {
                            return 'Confirm Password is required';
                          }
                          if (value != _passwordController.text) {
                            return 'Passwords do not match';
                          }
                          return null;
                        },
                      ),
                      SizedBox(
                        height: 45,
                      ),
                      SizedBox(
                        height: 40,
                        child: MainButtonWidget(
                            title: "Change",
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                changePassword();
                              }
                            }),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}
