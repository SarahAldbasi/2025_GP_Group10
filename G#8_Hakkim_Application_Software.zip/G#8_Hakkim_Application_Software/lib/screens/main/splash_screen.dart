import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/firebase_messaging_service.dart';
import 'package:hakkim/main.dart';
import 'package:hakkim/screens/auth/welcome_screen.dart';
import 'package:hakkim/screens/main/wait_verification_screen.dart';
import 'package:hakkim/screens/matches/home_screen.dart';
import 'package:hakkim/widgets/alert_widgets.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  _updateFirebaseToken() async {
    await FirebaseFirestore.instance
        .collection("users")
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .update({"fcm_token": await FirebaseMessaging.instance.getToken()});
  }

  void waitAndNavigate() async {
    bool status = false;
    if (FirebaseAuth.instance.currentUser != null) {
      status = await checkIfUserVified();
      _updateFirebaseToken();
    }
    await Future.delayed(Duration(seconds: 2));

    if (FirebaseAuth.instance.currentUser != null) {
      if (status) {
        Get.offAll(() => HomeScreen(), transition: Transition.circularReveal);
      } else {
        Get.offAll(() => WaitVerificationScreen(),
            transition: Transition.circularReveal);
      }
    } else {
      Get.offAll(() => WelcomeScreen(), transition: Transition.circularReveal);
    }
  }

  Future<bool> checkIfUserVified() async {
    try {
      final Map<String, dynamic> data = await FirebaseFirestore.instance
          .collection("users")
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .get()
          .then((doc) async {
        return doc.data() as Map<String, dynamic>;
      });

      String? refereePin = data['refereePin'];

      if (refereePin == null) {
        refereePin = generatePin(5);
        await FirebaseFirestore.instance
            .collection("users")
            .doc(FirebaseAuth.instance.currentUser!.uid)
            .update({"refereePin": refereePin});
      }

      if (data['verificationStatus'] != 'approved') {
        return false;
      }

      return true;
    } catch (e) {
      showMessageSnackbar("Error Unexpected");
      logger.e(e);
      return false;
    }
  }

  String generatePin(int length) {
    const String characters =
        '0123456789'; // You can change this to include any characters you want
    final Random random = Random();
    return String.fromCharCodes(List.generate(length,
        (_) => characters.codeUnitAt(random.nextInt(characters.length))));
  }

  Future<void> initializeFirebaseMessaging() async {
    await FirebaseMessagingService.setupFirebaseMessaging();
  }

  @override
  void initState() {
    waitAndNavigate();
    initializeFirebaseMessaging();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Spacer(),
            Image(
              image: AssetImage("assets/images/app_logo.png"),
              width: size.width * 0.6,
            ),
            Spacer(),
            CircularProgressIndicator(),
            SizedBox(
              height: 50,
            ),
          ],
        ),
      ),
    );
  }
}
