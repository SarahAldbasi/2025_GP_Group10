import 'package:fluttertoast/fluttertoast.dart';
import 'package:hakkim/constants.dart';

void showMessageSnackbar(String message) {
  Fluttertoast.showToast(
    msg: message,
    toastLength: Toast.LENGTH_LONG,
    gravity: ToastGravity.BOTTOM,
    timeInSecForIosWeb: 1,
    backgroundColor: kBackgroundColor,
    fontSize: 16.0,
  );
}
