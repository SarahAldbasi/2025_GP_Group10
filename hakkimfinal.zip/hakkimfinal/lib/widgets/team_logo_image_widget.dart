import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class TeamLogoImageWidget extends StatelessWidget {
  const TeamLogoImageWidget({
    super.key,
    required this.imageUrl,
    this.width = 50,
    this.height,
  });

  final String imageUrl;
  final double width;
  final double? height;

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: imageUrl,
      width: width,
      height: height,
      placeholder: (context, url) => CircularProgressIndicator(),
      errorWidget: (context, url, error) => Image(
        image: AssetImage("assets/images/app_logo.png"),
        width: width,
      ),
    );
  }
}
