import 'package:flutter/material.dart';
import 'package:hakkim/constants.dart';

class MainButtonWidget extends StatelessWidget {
  const MainButtonWidget({
    super.key,
    required this.title,
    required this.onPressed,
    this.reverseColor = false,
  });

  final String title;
  final bool reverseColor;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: double.infinity,
        height: 50.0,
        decoration: BoxDecoration(
          color: reverseColor ? null : kPrimaryColor,
          borderRadius: BorderRadius.circular(20.0),
          border: reverseColor
              ? Border.all(color: kPrimaryColor, width: 1.5)
              : null,
        ),
        child: Center(
          child: Text(
            title,
            style: TextStyle(
                fontSize: 18,
                color: reverseColor ? Colors.white : kSecondaryColor,
                fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
