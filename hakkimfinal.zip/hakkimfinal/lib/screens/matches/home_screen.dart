import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/extentions.dart';
import 'package:hakkim/main.dart';
import 'package:hakkim/screens/main/notification_screen.dart';
import 'package:hakkim/screens/matches/all_matches_screen.dart';
import 'package:hakkim/screens/matches/match_details_screen.dart';
import 'package:hakkim/screens/profile/profile_screen.dart';
import 'package:hakkim/widgets/grey_button_widget.dart';
import 'package:hakkim/widgets/team_logo_image_widget.dart';
import 'package:hakkim/widgets/user_avatar_image_widget.dart';
import 'package:jiffy/jiffy.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final currentUser = FirebaseAuth.instance.currentUser;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  Future<Map<String, dynamic>?> fetchNearestMatch() async {
    try {
      // Get the current date or any specified date
      DateTime currentDate = DateTime.now();

      // Reference to the Firestore collection
      CollectionReference matchesCollection =
          FirebaseFirestore.instance.collection('matches');

      final mainReferee = Filter('mainReferee.id', isEqualTo: currentUser!.uid);
      final assistantReferee1 =
          Filter('assistantReferee1.id', isEqualTo: currentUser!.uid);
      final assistantReferee2 =
          Filter('assistantReferee2.id', isEqualTo: currentUser!.uid);
      final orFilter =
          Filter.or(mainReferee, assistantReferee1, assistantReferee2);

      // Query to get matches with dates greater than or equal to the current date
      QuerySnapshot upcomingMatches = await matchesCollection
          .where(orFilter)
          .where('date', isGreaterThanOrEqualTo: currentDate)
          .orderBy('date', descending: false)
          .limit(1) // Limit to 1 document (nearest match)
          .get();

      if (upcomingMatches.docs.isNotEmpty) {
        return upcomingMatches.docs.first.data() as Map<String, dynamic>;
      }

      return null;
    } catch (e) {
      print('Error fetching nearest match: $e');
      return null;
    }
  }

  Future<List<Map<String, dynamic>>> fetchMatches() async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      // Reference to the Firestore collection
      CollectionReference matchesCollection =
          FirebaseFirestore.instance.collection('matches');

      final mainReferee = Filter('mainReferee.id', isEqualTo: currentUser!.uid);
      final assistantReferee1 =
          Filter('assistantReferee1.id', isEqualTo: currentUser.uid);
      final assistantReferee2 =
          Filter('assistantReferee2.id', isEqualTo: currentUser.uid);
      final orFilter =
          Filter.or(mainReferee, assistantReferee1, assistantReferee2);

      // Query to get matches with dates greater than or equal to the current date
      QuerySnapshot upcomingMatches = await matchesCollection
          .where(orFilter)
          .orderBy('date', descending: false)
          .limit(3) // Limit to 1 document (nearest match)
          .get();

      print(upcomingMatches.docs.length);

      return upcomingMatches.docs
          .map((match) => match.data() as Map<String, dynamic>)
          .toList();
    } catch (e) {
      print('Error fetching nearest match: $e');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: kSecondaryColor,
        key: scaffoldKey,
        // drawer: SideMenuWidget(
        //     size: size, currentUser: currentUser, scaffoldKey: scaffoldKey),
        body: RefreshIndicator(
          onRefresh: () async {
            setState(() {});
          },
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            children: [
              SizedBox(
                height: size.height * 0.1,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  avaterWidget(),
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Get.to(
                          () => NotificationScreen(),
                          transition: Transition.circularReveal,
                        ),
                        icon: Icon(
                          Icons.notifications,
                          color: Colors.white,
                          size: 25,
                        ),
                      ),
                      // IconButton(
                      //   onPressed: () {
                      //     scaffoldKey.currentState!.openDrawer();
                      //   },
                      //   icon: Icon(
                      //     Icons.menu,
                      //     color: Colors.white,
                      //     size: 25,
                      //   ),
                      // ),
                    ],
                  )
                ],
              ),
              SizedBox(
                height: 50,
              ),
              upcomingMatchWidget(size),
              SizedBox(
                height: 30,
              ),
              allMatchesWidget(size),
              SizedBox(
                height: size.height * 0.05,
              ),
            ],
          ),
        ));
  }

  Widget allMatchesWidget(Size size) {
    return FutureBuilder<List<Map<String, dynamic>>>(
        future: fetchMatches(),
        builder: (context, snapshot) {
          final matches = snapshot.data;

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "All Matches",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                width: double.infinity,
                // height: 200,
                decoration: BoxDecoration(
                  color: kBackgroundColor,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: (snapshot.connectionState == ConnectionState.waiting)
                    ? SizedBox(
                        height: 250,
                        child: Center(
                          child: CircularProgressIndicator(),
                        ),
                      )
                    : Column(children: [
                        SizedBox(
                          height: 20,
                        ),
                        if (matches!.isNotEmpty)
                          ...matches.map((match) => allMatchCardWidget(match))
                        else
                          Center(
                            child: Column(
                              children: [
                                Icon(
                                  Icons.sports_basketball_sharp,
                                  color: kPrimaryColor,
                                  size: 100,
                                ),
                                SizedBox(
                                  height: 25,
                                ),
                                Text(
                                  "NO MATCHES",
                                  style: TextStyle(
                                      fontSize: 15,
                                      color: kTextColor,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        SizedBox(
                          height: 10,
                        ),
                        GreyButtonWidget(
                          title: "See All",
                          onPress: () => Get.to(() => AllMatchesScreen(),
                              transition: Transition.circularReveal),
                          width: size.width * 0.4,
                        ),
                        SizedBox(
                          height: 20,
                        ),
                      ]),
              ),
            ],
          );
        });
  }

  Container upcomingMatchWidget(Size size) {
    return Container(
      width: double.infinity,
      // height: 200,
      decoration: BoxDecoration(
        color: kBackgroundColor2,
        borderRadius: BorderRadius.circular(25),
      ),
      child: FutureBuilder<Map<String, dynamic>?>(
          future: fetchNearestMatch(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return SizedBox(
                height: 300,
                child: Center(
                  child: CircularProgressIndicator(),
                ),
              );
            }

            final lastMatch = snapshot.data;

            return Column(
              children: [
                Container(
                  width: size.width * 0.5,
                  height: 40,
                  decoration: BoxDecoration(
                      color: kPrimaryColor,
                      borderRadius:
                          BorderRadius.vertical(bottom: Radius.circular(25))),
                  child: Center(
                    child: Text(
                      "Upcoming match",
                      style: TextStyle(
                          fontSize: 17,
                          color: kSecondaryColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: lastMatch == null
                      ? Center(
                          child: Column(
                            children: [
                              Icon(
                                Icons.sports_basketball_sharp,
                                color: kPrimaryColor,
                                size: 100,
                              ),
                              SizedBox(
                                height: 25,
                              ),
                              Text(
                                "NO UPCOMING MATCHES",
                                style: TextStyle(
                                    fontSize: 15,
                                    color: kTextColor,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        )
                      : Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Column(
                                    children: [
                                      TeamLogoImageWidget(
                                        imageUrl:
                                            "${lastMatch.getNested("homeTeam.logo")} ",
                                        width: 65,
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      LayoutBuilder(
                                          builder: (context, constraints) {
                                        return SizedBox(
                                          // width: 70,
                                          width: constraints.maxWidth,
                                          child: Text(
                                            "${lastMatch.getNested("homeTeam.name".toString())} ",
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white,
                                            ),
                                          ),
                                        );
                                      }),
                                    ],
                                  ),
                                ),
                                Flexible(
                                  flex: 1,
                                  child: Column(
                                    // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      SizedBox(
                                        height: 25,
                                      ),
                                      GreyButtonWidget(
                                          title: "VS",
                                          width: 60,
                                          isBold: true,
                                          onPress: () {}),
                                      SizedBox(
                                        height: 25,
                                      ),
                                      Text(
                                        Jiffy.parse(
                                                (lastMatch["date"] as Timestamp)
                                                    .toDate()
                                                    .toIso8601String())
                                            .format(pattern: "dd MMM yyyy"),
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white,
                                        ),
                                      ),
                                      Text(
                                        Jiffy.parse(
                                                (lastMatch["date"] as Timestamp)
                                                    .toDate()
                                                    .toIso8601String())
                                            .format(pattern: "hh:mm a"),
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Flexible(
                                  flex: 1,
                                  child: Column(
                                    children: [
                                      TeamLogoImageWidget(
                                        imageUrl: lastMatch
                                            .getNested("awayTeam.logo")
                                            .toString(),
                                        width: 65,
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      LayoutBuilder(
                                          builder: (context, constraints) {
                                        return SizedBox(
                                          // width: 70,
                                          width: constraints.maxWidth,
                                          child: Text(
                                            lastMatch
                                                .getNested("awayTeam.name")
                                                .toString(),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white,
                                            ),
                                          ),
                                        );
                                      }),
                                    ],
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                ),
                if (lastMatch != null)
                  Column(
                    children: [
                      SizedBox(
                        height: 25,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 40),
                        child: GreyButtonWidget(
                          title: "Match Details",
                          onPress: () => Get.to(
                            () => MatchDetailsScreen(
                              match: lastMatch,
                            ),
                            transition: Transition.circularReveal,
                          ),
                        ),
                      ),
                    ],
                  ),
                SizedBox(
                  height: 25,
                ),
              ],
            );
          }),
    );
  }

  Row avaterWidget() {
    return Row(
      children: [
        Hero(
          tag: "avatar",
          child: GestureDetector(
            onTap: () => Get.to(() => ProfileScreen()),
            child: UserAvatarImageWidget(
              imageUrl: currentUser!.photoURL.toString(),
            ),
          ),
        ),
        SizedBox(
          width: 15,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Hello!",
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            Text(
              currentUser!.displayName!,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                color: kTextColor,
              ),
            ),
          ],
        )
      ],
    );
  }

  Widget allMatchCardWidget(Map<String, dynamic> match) {
    return InkWell(
      onTap: () => Get.to(
        () => MatchDetailsScreen(
          match: match,
        ),
        transition: Transition.circularReveal,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  flex: 2,
                  child: Row(
                    children: [
                      TeamLogoImageWidget(
                        imageUrl: match.getNested("homeTeam.logo").toString(),
                        width: 40,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Text(
                          match.getNested("homeTeam.name").toString(),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Flexible(
                  flex: 1,
                  child: GreyButtonWidget(
                      title: "VS",
                      width: 50,
                      height: 30,
                      fontSize: 15,
                      isBold: true,
                      onPress: () {}),
                ),
                Flexible(
                  flex: 2,
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          ("${match.getNested("awayTeam.name")} "),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      TeamLogoImageWidget(
                        imageUrl: match.getNested("awayTeam.logo").toString(),
                        width: 40,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: kTextColor,
            thickness: 0.25,
            height: 25,
          ),
        ],
      ),
    );
  }
}
