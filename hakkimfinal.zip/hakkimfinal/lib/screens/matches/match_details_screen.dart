import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/extentions.dart';
import 'package:hakkim/core/firestore_service.dart';
import 'package:hakkim/widgets/grey_button_widget.dart';
import 'package:hakkim/widgets/team_logo_image_widget.dart';
import 'package:hakkim/widgets/user_avatar_image_widget.dart';
import 'package:jiffy/jiffy.dart';

class MatchDetailsScreen extends StatefulWidget {
  const MatchDetailsScreen({super.key, required this.match});

  final Map<String, dynamic> match;

  @override
  State<MatchDetailsScreen> createState() => _MatchDetailsScreenState();
}

class _MatchDetailsScreenState extends State<MatchDetailsScreen> {
  final currentUser = FirebaseAuth.instance.currentUser;
  Map<String, dynamic>? mainReferee;
  Map<String, dynamic>? assistant1Referee;
  Map<String, dynamic>? assistant2Referee;

  @override
  void initState() {
    getRefereeData();
    super.initState();
  }

  getRefereeData() async {
    mainReferee = await FirestoreService.getRefereeData(
        widget.match.getNested("mainReferee.id"));
    assistant1Referee = await FirestoreService.getRefereeData(
        widget.match.getNested("assistantReferee1.id"));
    assistant2Referee = await FirestoreService.getRefereeData(
        widget.match.getNested("assistantReferee2.id"));
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: ListView(
        children: [
          Container(
            height: 350,
            decoration: BoxDecoration(
                image: DecorationImage(
              image: AssetImage(
                "assets/images/goal_background.png",
              ),
              fit: BoxFit.cover,
            )),
            alignment: Alignment.center,
            //
            child: SizedBox(
              width: size.width * 0.8,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                      onPressed: () => Get.back(),
                      icon: Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                        size: 25,
                      )),
                  Container(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Flexible(
                        flex: 1,
                        child: Column(
                          children: [
                            TeamLogoImageWidget(
                              imageUrl: widget.match
                                  .getNested("homeTeam.logo")
                                  .toString(),
                              width: 70,
                              height: 70,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              "${widget.match.getNested("homeTeam.name")} ",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                            LayoutBuilder(builder: (context, constraints) {
                              return SizedBox(
                                width: constraints.maxWidth,
                                height: 1,
                                child: Container(),
                              );
                            }),
                          ],
                        ),
                      ),
                      Flexible(
                        flex: 1,
                        child: GreyButtonWidget(
                            title: "VS",
                            width: 60,
                            isBold: true,
                            onPress: () {}),
                      ),
                      Flexible(
                        flex: 1,
                        child: Column(
                          children: [
                            TeamLogoImageWidget(
                              imageUrl: widget.match
                                  .getNested("awayTeam.logo")
                                  .toString(),
                              width: 70,
                              height: 70,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              widget.match
                                  .getNested("awayTeam.name")
                                  .toString(),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                            LayoutBuilder(builder: (context, constraints) {
                              return SizedBox(
                                width: constraints.maxWidth,
                                height: 1,
                                child: Container(),
                              );
                            }),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Container(),
                  Container(),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: 20),
            padding: EdgeInsets.all(20),
            // height: 200,
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.label,
                      color: kPrimaryColor,
                      size: 25,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Text(
                      widget.match.getNested("code") ?? "Null",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Icon(
                      Icons.calendar_month,
                      color: kPrimaryColor,
                      size: 25,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Text(
                      Jiffy.parse((widget.match["date"] as Timestamp)
                              .toDate()
                              .toIso8601String())
                          .format(pattern: "dd MMM yyyy hh:mm a"),
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Icon(
                      Icons.tag,
                      color: kPrimaryColor,
                      size: 25,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Text(
                      widget.match.getNested("league"),
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Icon(
                      Icons.location_pin,
                      color: kPrimaryColor,
                      size: 25,
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Text(
                      widget.match.getNested('venue').toString(),
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: 20),
            padding: EdgeInsets.all(20),
            // height: 200,
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              children: [
                Text(
                  "Main Referee",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                if (mainReferee != null)
                  Padding(
                    padding: EdgeInsets.only(right: 25),
                    child: Column(
                      children: [
                        UserAvatarImageWidget(
                          imageUrl: mainReferee?.getNested('photoURL') ?? "",
                        ),
                        SizedBox(
                          height: 7.5,
                        ),
                        Text(
                          "${mainReferee?.getNested('firstName').toString()} ${mainReferee?.getNested('lastName').toString() ?? ''}",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: mainReferee!.getNested('uid') ==
                                    currentUser!.uid
                                ? kPrimaryColor
                                : Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: 20),
            padding: EdgeInsets.all(20),
            // height: 200,
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              children: [
                Text(
                  "Assistant Referee",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    if (assistant1Referee != null)
                      Padding(
                        padding: EdgeInsets.only(right: 25),
                        child: Column(
                          children: [
                            UserAvatarImageWidget(
                              imageUrl:
                                  assistant1Referee?.getNested('photoURL') ??
                                      "",
                            ),
                            SizedBox(
                              height: 7.5,
                            ),
                            Text(
                              "${assistant1Referee?.getNested('firstName').toString()} ${assistant1Referee?.getNested('lastName').toString() ?? ''}",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                color: assistant1Referee!.getNested('uid') ==
                                        currentUser!.uid
                                    ? kPrimaryColor
                                    : Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    if (assistant2Referee != null)
                      Padding(
                        padding: EdgeInsets.only(right: 25),
                        child: Column(
                          children: [
                            UserAvatarImageWidget(
                              imageUrl:
                                  assistant2Referee?.getNested('photoURL') ??
                                      "",
                            ),
                            SizedBox(
                              height: 7.5,
                            ),
                            Text(
                              "${assistant2Referee?.getNested('firstName').toString()} ${assistant2Referee?.getNested('lastName').toString() ?? ''}",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                color: assistant2Referee!.getNested('uid') ==
                                        currentUser!.uid
                                    ? kPrimaryColor
                                    : Colors.white,
                              ),
                            ),
                          ],
                        ),
                      )
                  ],
                )
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: 20),
            // padding: EdgeInsets.all(15),
            // height: 200,
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    children: [
                      Container(
                        // width: double.infinity,
                        height: 70,
                        decoration: BoxDecoration(
                          color: kGreyButtonColor,
                          border: Border(
                              right:
                                  BorderSide(color: kTextColor, width: 0.125)),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          "Match goals",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      Container(
                        height: 80,
                        decoration: BoxDecoration(
                          border: Border(
                            right: BorderSide(color: kTextColor, width: 0.125),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          " ${widget.match.getNested('matchGoals') ?? 'NaN'}",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    children: [
                      Container(
                        // width: double.infinity,
                        height: 70,
                        decoration: BoxDecoration(
                          color: kGreyButtonColor,
                          border: Border(
                              left:
                                  BorderSide(color: kTextColor, width: 0.125)),
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(20),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          "Match outs",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      Container(
                        height: 80,
                        decoration: BoxDecoration(
                          border: Border(
                            left: BorderSide(color: kTextColor, width: 0.125),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          " ${widget.match.getNested('matchOuts') ?? 'NaN'}",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
        ],
      ),
    );
  }
}
