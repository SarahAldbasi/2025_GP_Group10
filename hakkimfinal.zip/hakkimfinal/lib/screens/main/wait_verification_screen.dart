import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/main.dart';
import 'package:hakkim/screens/main/splash_screen.dart';
import 'package:hakkim/screens/matches/home_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hakkim/widgets/alert_widgets.dart';

class WaitVerificationScreen extends StatefulWidget {
  const WaitVerificationScreen({super.key});

  @override
  State<WaitVerificationScreen> createState() => _WaitVerificationScreenState();
}

class _WaitVerificationScreenState extends State<WaitVerificationScreen> {
  bool isLoading = false;

  Future<bool> checkIfUserVified() async {
    try {
      final String status = await FirebaseFirestore.instance
          .collection("users")
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .get()
          .then((doc) async {
        return doc.get('verificationStatus') ?? 'pending';
      });

      if (status == 'pending' || status == 'rejected') {
        return false;
      }

      return true;
    } catch (e) {
      showMessageSnackbar("Error Unexpected");
      logger.e(e);
      return false;
    }
  }

  Future<void> checkVerification() async {
    setState(() {
      isLoading = true;
    });

    final bool status = await checkIfUserVified();

    setState(() {
      isLoading = false;
    });

    // If verified, navigate to home screen
    if (status) {
      Get.offAll(() => HomeScreen(), transition: Transition.circularReveal);
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Spacer(),
            Image(
              image: AssetImage("assets/images/app_logo.png"),
              width: size.width * 0.6,
            ),
            SizedBox(height: 30),
            Text(
              "Hello ${FirebaseAuth.instance.currentUser!.displayName}",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Text(
              "Your account isn't verified",
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 10),
            Text(
              "Please contact the admin to verify your account",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
            Spacer(),
            ElevatedButton(
              onPressed: isLoading ? null : checkVerification,
              style: ElevatedButton.styleFrom(
                backgroundColor: kPrimaryColor,
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: isLoading
                  ? CircularProgressIndicator(color: Colors.white)
                  : Text(
                      "Refresh",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
            ),
            SizedBox(height: 10),
            TextButton(
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                Get.offAll(() => SplashScreen());
              },
              child: Text(
                "Logout",
                style: TextStyle(fontSize: 15, color: kPrimaryColor),
              ),
            ),
            SizedBox(height: 50),
          ],
        ),
      ),
    );
  }
}
