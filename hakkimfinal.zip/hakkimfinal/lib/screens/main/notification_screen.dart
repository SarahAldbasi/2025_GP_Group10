import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/extentions.dart';
import 'package:jiffy/jiffy.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final currentUser = FirebaseAuth.instance.currentUser;

  Future<List<Map<String, dynamic>>> fetchNotifications() async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;

      // Fetch documents from the 'notifications' collection
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('notifications')
          .where('targetUserIds', arrayContains: currentUser!.uid)
          .orderBy("timestamp", descending: true)
          .get();

      // Convert documents to a list of maps
      List<Map<String, dynamic>> notifications = snapshot.docs
          .map((doc) => doc.data() as Map<String, dynamic>)
          .toList();

      return notifications;
    } catch (e) {
      print('Error fetching notifications: $e');
      return []; // Return an empty list in case of error
    }
  }

  bool notificatoinEnabledFlag = true;

  void checkNotificationStatus() async {
    notificatoinEnabledFlag = await FirebaseFirestore.instance
        .collection("users")
        .doc(currentUser!.uid)
        .get()
        .then((doc) => (doc.data()!['fcm_token'] as String).isNotEmpty);

    setState(() {});
  }

  void changeNotificationStatus(bool value) async {
    setState(() {
      notificatoinEnabledFlag = value;
    });

    String? token = "";

    if (value) {
      token = await FirebaseMessaging.instance.getToken();
    }

    await FirebaseFirestore.instance
        .collection("users")
        .doc(currentUser!.uid)
        .update({"fcm_token": token});
  }

  @override
  void initState() {
    checkNotificationStatus();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() {});
        },
        child: ListView(
          padding: const EdgeInsets.symmetric(
            horizontal: 15,
          ),
          children: [
            SizedBox(
              height: size.height * 0.075,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                    onPressed: () => Get.back(),
                    icon: Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                      size: 25,
                    )),
                Text(
                  "Notifications",
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Transform.scale(
                  scale: 0.8,
                  child: Switch(
                    value: notificatoinEnabledFlag,
                    onChanged: (value) => changeNotificationStatus(value),
                    activeColor: kPrimaryColor,
                    inactiveThumbColor: kGreyButtonColor,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            FutureBuilder<List<Map<String, dynamic>>>(
                future: fetchNotifications(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }

                  return ListView(
                      shrinkWrap: true,
                      primary: false,
                      children: snapshot.data!.map((notification) {
                        return notificationCardWidget(notification);
                      }).toList());
                })
          ],
        ),
      ),
    );
  }

  Container notificationCardWidget(Map<String, dynamic> notification) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(bottom: 15),
      padding: EdgeInsets.all(20),
      // height: 200,
      decoration: BoxDecoration(
        color: kBackgroundColor,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                notification.getNested("title") ?? "New Notification",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Row(
                children: [
                  Text(
                    Jiffy.parse(
                            (notification.getNested("timestamp") as Timestamp)
                                .toDate()
                                .toIso8601String())
                        .fromNow(),
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Icon(
                    Icons.circle,
                    color: kPrimaryColor,
                    size: 10,
                  )
                ],
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            notification.getNested("message").toString(),
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
