package com.example.myapplication

import kotlin.math.*

data class Vec3(val x: Double, val y: Double, val z: Double)

fun trilaterate3D(
    p1: Vec3, d1: Double,
    p2: Vec3, d2: Double,
    p3: Vec3, d3: Double
): Vec3? {
    fun unit(v: Vec3): Vec3 {
        val mag = sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
        return Vec3(v.x / mag, v.y / mag, v.z / mag)
    }

    fun dot(a: Vec3, b: Vec3): Double = a.x * b.x + a.y * b.y + a.z * b.z

    val ex = unit(Vec3(p2.x - p1.x, p2.y - p1.y, p2.z - p1.z))
    val i = dot(ex, Vec3(p3.x - p1.x, p3.y - p1.y, p3.z - p1.z))
    val temp = Vec3(
        p3.x - p1.x - i * ex.x,
        p3.y - p1.y - i * ex.y,
        p3.z - p1.z - i * ex.z
    )
    val ey = unit(temp)
    val ez = Vec3(
        ex.y * ey.z - ex.z * ey.y,
        ex.z * ey.x - ex.x * ey.z,
        ex.x * ey.y - ex.y * ey.x
    )

    val d = sqrt((p2.x - p1.x).pow(2) + (p2.y - p1.y).pow(2) + (p2.z - p1.z).pow(2))
    val j = dot(ey, Vec3(p3.x - p1.x, p3.y - p1.y, p3.z - p1.z))

    val x = (d1.pow(2) - d2.pow(2) + d.pow(2)) / (2 * d)
    val y = (d1.pow(2) - d3.pow(2) + i.pow(2) + j.pow(2) - 2 * i * x) / (2 * j)
    val zSquared = d1.pow(2) - x.pow(2) - y.pow(2)

    if (zSquared < 0 && abs(zSquared) >= 1e-4) return null
    val z = sqrt(max(0.0, zSquared))

    return Vec3(
        p1.x + x * ex.x + y * ey.x,
        p1.y + x * ex.y + y * ey.y,
        p1.z + x * ex.z + y * ey.z
    )
}
