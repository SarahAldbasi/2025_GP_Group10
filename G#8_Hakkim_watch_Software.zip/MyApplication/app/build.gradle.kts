plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    id("com.google.gms.google-services")
}

android {
    namespace = "com.example.myapplication"  // ✅ Matches your package name
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.myapplication"
        minSdk = 28  // ✅ Minimum for Wear OS 3.0
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        // ⚙️ Let's update to Java 17 (recommended for Compose and modern Android)
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"  // ✅ Use 17 for Kotlin as well
    }

    buildFeatures {
        compose = true  // ✅ Enable Jetpack Compose
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.4"  // ✅ Set correct version for Compose
    }
}

dependencies {
    // ✅ Keep these core dependencies
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)

    // ✅ Unit test and Android test libraries
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // ✅ Jetpack Compose for Wear OS
    implementation("androidx.wear.compose:compose-material:1.2.0")

    // ✅ Compose essentials
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.compose.ui:ui:1.6.1")
    implementation("androidx.compose.ui:ui-tooling-preview:1.6.1")

    // ✅ Lifecycle for Compose
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.firestore)  // ✅ Firestore






    implementation("io.coil-kt:coil-compose:2.1.0")
    implementation("org.eclipse.paho:org.eclipse.paho.client.mqttv3:1.2.5")
    implementation("org.eclipse.paho:org.eclipse.paho.android.service:1.1.1")
    implementation("org.eclipse.paho:org.eclipse.paho.client.mqttv3:1.2.5")
    implementation("androidx.compose.material:material-icons-extended:1.5.4")




}
