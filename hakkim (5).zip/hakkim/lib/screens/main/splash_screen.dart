import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/firebase_messaging_service.dart';
import 'package:hakkim/screens/auth/welcome_screen.dart';
import 'package:hakkim/screens/matches/home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  void waitAndNavigate() async {
    await Future.delayed(Duration(seconds: 2));

    if (FirebaseAuth.instance.currentUser != null) {
      Get.offAll(() => HomeScreen(), transition: Transition.circularReveal);
    } else {
      Get.offAll(() => WelcomeScreen(), transition: Transition.circularReveal);
    }
  }

  Future<void> initializeFirebaseMessaging() async {
    await FirebaseMessagingService.setupFirebaseMessaging();
  }

  @override
  void initState() {
    waitAndNavigate();
    initializeFirebaseMessaging();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Spacer(),
            Image(
              image: AssetImage("assets/images/app_logo.png"),
              width: size.width * 0.6,
            ),
            Spacer(),
            CircularProgressIndicator(),
            SizedBox(
              height: 50,
            ),
          ],
        ),
      ),
    );
  }
}
