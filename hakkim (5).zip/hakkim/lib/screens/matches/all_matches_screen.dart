import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/core/extentions.dart';
import 'package:hakkim/screens/matches/match_details_screen.dart';
import 'package:hakkim/widgets/grey_button_widget.dart';
import 'package:hakkim/widgets/team_logo_image_widget.dart';
import 'package:jiffy/jiffy.dart';

class AllMatchesScreen extends StatefulWidget {
  const AllMatchesScreen({super.key});

  @override
  State<AllMatchesScreen> createState() => _AllMatchesScreenState();
}

class _AllMatchesScreenState extends State<AllMatchesScreen> {
  Future<List<Map<String, dynamic>>> fetchMatches() async {
    try {
      // Reference to the Firestore collection
      CollectionReference matchesCollection =
          FirebaseFirestore.instance.collection('matches');

      // Query to get matches with dates greater than or equal to the current date
      QuerySnapshot upcomingMatches =
          await matchesCollection.orderBy('date', descending: true).get();

      return upcomingMatches.docs
          .map((match) => match.data() as Map<String, dynamic>)
          .toList();
    } catch (e) {
      print('Error fetching nearest match: $e');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: ListView(
        children: [
          SizedBox(
            height: size.height * 0.075,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                  onPressed: () => Get.back(),
                  icon: Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                    size: 25,
                  )),
              Text(
                "All Matches",
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(
                width: 25,
                height: 25,
              )
            ],
          ),
          SizedBox(
            height: 30,
          ),
          FutureBuilder<List<Map<String, dynamic>>>(
              future: fetchMatches(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }

                return ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  shrinkWrap: true,
                  primary: false,
                  children: List.generate(snapshot.data!.length,
                      (index) => matchCardWidget(snapshot.data![index])),
                );
              })
        ],
      ),
    );
  }

  Container matchCardWidget(Map<String, dynamic> match) {
    return Container(
      width: double.infinity,
      // height: 200,
      margin: EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: kBackgroundColor,
        borderRadius: BorderRadius.circular(25),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            height: 95,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    TeamLogoImageWidget(
                      imageUrl: match.getNested("homeTeam.logo").toString(),
                      width: 40,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      match.getNested("homeTeam.name").toString(),
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                GreyButtonWidget(
                    title: "VS",
                    width: 50,
                    height: 30,
                    fontSize: 15,
                    isBold: true,
                    onPress: () {}),
                Row(
                  children: [
                    Text(
                      match.getNested("awayTeam.name").toString(),
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    TeamLogoImageWidget(
                      imageUrl: match.getNested("awayTeam.logo").toString(),
                      width: 40,
                    ),
                  ],
                ),
              ],
            ),
          ),
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 50,
                  // width: double.infinity,
                  decoration: BoxDecoration(
                      color: kBackgroundColor2,
                      borderRadius:
                          BorderRadius.only(bottomLeft: Radius.circular(25))),
                  alignment: Alignment.center,
                  child: Text(
                    Jiffy.parse((match["date"] as Timestamp)
                            .toDate()
                            .toIso8601String())
                        .format(pattern: "dd MMM yyyy hh:mm a"),
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: kTextColor,
                    ),
                  ),
                ),
              ),
              Expanded(
                child: InkWell(
                  onTap: () => Get.to(
                    () => MatchDetailsScreen(
                      match: match,
                    ),
                    transition: Transition.circularReveal,
                  ),
                  child: Container(
                    height: 50,
                    // width: double.infinity,
                    decoration: BoxDecoration(
                        color: kPrimaryColor,
                        borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(25))),
                    alignment: Alignment.center,
                    child: Text(
                      "View details",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: kGreyButtonColor,
                      ),
                    ),
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
