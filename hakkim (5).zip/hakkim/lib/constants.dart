import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xFF6AB100);
const Color kSecondaryColor = Color(0xFF171717);
const Color kTextColor = Color(0xFFBBBCBD);
const Color kBackgroundColor = Color(0xFF212121);
const Color kBackgroundColor2 = Color(0xFF2B2B2B);
const Color kGreyButtonColor = Color(0xFF373737);
