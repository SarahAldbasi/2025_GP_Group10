extension SafeAccess on Map<String, dynamic> {
  dynamic getNested(String keyPath) {
    final keys = keyPath.split('.');
    dynamic current = this;

    for (final key in keys) {
      if (current is Map<String, dynamic> && current.containsKey(key)) {
        current = current[key];
      } else {
        return null; // Return null if any key in the path is missing or not a map
      }
    }

    return current;
  }
}

extension NameParsing on String {
  /// Returns the first name (the first word in the string)
  String get firstName {
    if (trim().isEmpty) return '';
    return trim().split(' ').first;
  }

  /// Returns the last name (the last word in the string)
  String get lastName {
    if (trim().isEmpty) return '';
    List<String> words = trim().split(' ');
    return words.length > 1 ? words.last : '';
  }
}
