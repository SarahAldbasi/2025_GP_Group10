extension SafeAccess on Map<String, dynamic> {
  dynamic getNested(String keyPath) {
    final keys = keyPath.split('.');
    dynamic current = this;

    for (final key in keys) {
      if (current is Map<String, dynamic> && current.containsKey(key)) {
        current = current[key];
      } else {
        return null; // Return null if any key in the path is missing or not a map
      }
    }

    return current;
  }
}
