import 'package:get/get.dart';
import 'package:hakkim/constants.dart';

void showMessageSnackbar(String message) {
  Get.snackbar(
    "Message",
    message,
    colorText: kTextColor,
    backgroundColor: kBackgroundColor,
  );
}
