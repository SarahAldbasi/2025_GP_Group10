import 'package:flutter/material.dart';
import 'package:hakkim/constants.dart';

class GreyButtonWidget extends StatelessWidget {
  const GreyButtonWidget({
    super.key,
    required this.title,
    required this.onPress,
    this.width = double.infinity,
    this.isBold = false,
    this.height = 40,
    this.fontSize = 18,
  });

  final VoidCallback onPress;
  final String title;
  final double width;
  final bool isBold;
  final double height;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPress,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: kGreyButtonColor,
          borderRadius: BorderRadius.circular(25),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 4,
              offset: Offset(4, 8), // Shadow position
            ),
          ],
        ),
        child: Center(
          child: Text(
            title,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: isBold ? FontWeight.bold : null,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
