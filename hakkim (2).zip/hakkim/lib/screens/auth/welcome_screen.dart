import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/screens/auth/log_in_screen.dart';
import 'package:hakkim/screens/auth/sign_up_screen.dart';
import 'package:hakkim/widgets/main_button_widget.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: kSecondaryColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(),
            Container(),
            Image(
              image: AssetImage("assets/images/app_logo.png"),
              width: size.width * 0.75,
            ),
            Container(),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Hello!",
                  style: TextStyle(
                    fontSize: 35,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(
                  height: 8.0,
                ),
                Text(
                  "Welcome to Hakkim! A platform that simplifies",
                  style: TextStyle(fontSize: 15, color: kTextColor),
                ),
                Text(
                  "match management and officiating all in one place.",
                  style: TextStyle(fontSize: 15, color: kTextColor),
                ),
              ],
            ),
            Column(
              children: [
                MainButtonWidget(
                  title: "LOG IN",
                  onPressed: () => Get.to(
                    () => LogInScreen(),
                    transition: Transition.downToUp,
                  ),
                  reverseColor: true,
                ),
                SizedBox(
                  height: 15.0,
                ),
                MainButtonWidget(
                  title: "SIGN UP",
                  onPressed: () => Get.to(
                    () => SignUpScreen(),
                    transition: Transition.downToUp,
                  ),
                ),
              ],
            ),
            Container(),
          ],
        ),
      ),
    );
  }
}
