import 'dart:ui';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hakkim/constants.dart';
import 'package:hakkim/screens/main/splash_screen.dart';

class SideMenuWidget extends StatelessWidget {
  const SideMenuWidget({
    super.key,
    required this.size,
    required this.currentUser,
    required this.scaffoldKey,
  });

  final Size size;
  final User? currentUser;
  final GlobalKey<ScaffoldState> scaffoldKey;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 2.0,
            sigmaY: 2.0,
          ),
          child: SizedBox.expand(
            child: Container(
              color: Colors.grey.withValues(alpha: 0.2),
            ),
          ),
        ),
        Drawer(
          backgroundColor: Colors.transparent,
          width: size.width * 0.6,
          child: Container(
            margin: EdgeInsets.symmetric(vertical: size.height * 0.1),
            decoration: BoxDecoration(
              color: kSecondaryColor,
              borderRadius: BorderRadius.horizontal(
                right: Radius.circular(25),
              ),
            ),
            child: Column(
              children: [
                Container(
                  height: 125,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: kGreyButtonColor,
                    borderRadius: BorderRadius.horizontal(
                      right: Radius.circular(25),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 4,
                        offset: Offset(4, 8), // Shadow position
                      ),
                    ],
                  ),
                  alignment: Alignment.center,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    // mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 15,
                      ),
                      if (currentUser!.photoURL == null)
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: kBackgroundColor2,
                          child: Icon(
                            Icons.person,
                            color: kPrimaryColor,
                            size: 22.5,
                          ),
                        )
                      else
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: kBackgroundColor2,
                          backgroundImage: AssetImage(currentUser!.photoURL!),
                        ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        currentUser!.displayName!,
                        maxLines: 2,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 85,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: kTextColor,
                        width: 0.25,
                      ),
                    ),
                  ),
                  child: Text(
                    "Profile",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                Container(
                  height: 85,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: kTextColor,
                        width: 0.25,
                      ),
                    ),
                  ),
                  child: Text(
                    "Matches",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                Container(
                  height: 85,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: kTextColor,
                        width: 0.25,
                      ),
                    ),
                  ),
                  child: Text(
                    "Settings",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                Spacer(),
                Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        scaffoldKey.currentState!.openDrawer();
                      },
                      icon: Icon(
                        Icons.logout,
                        color: Colors.red,
                        size: 20,
                      ),
                    ),
                    TextButton(
                      onPressed: () async {
                        await FirebaseAuth.instance.signOut();
                        Get.offAll(() => SplashScreen());
                      },
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                      ),
                      child: Text(
                        "Log Out",
                        style: TextStyle(
                            color: Colors.red,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5,
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}
